# Photonic Model

Проект для разработки, обучения и использования нейросетевой модели в задачах фотоники.

## Технологии

- **Python** — основной язык программирования.
- **uv** — управление зависимостями и виртуальным окружением.
- **Make** — автоматизация команд разработки.

## Структура проекта

```text
photonic_model/
├── src/
│   ├── main.py          # Точка входа
│   ├── app/             # Интерфейс приложения
│   ├── model/           # Нейросетевая модель
│   ├── dataset/         # Работа с данными
│   └── tests/           # Тесты
├── pyproject.toml       # Конфигурация проекта
├── uv.lock              # Зафиксированные зависимости
├── Makefile             # Команды разработки
└── README.md
```

### Описание модулей

- **`app/`** — пользовательский интерфейс приложения: терминал (`terminal.py`) и локальный веб-интерфейс (`server.py`, `static/`). Оба вызывают один расчётный адаптер `adapter.py`, поэтому результаты у них одинаковы.
- **`model/`** — архитектура нейронной сети, её обучение и использование.
- **`dataset/`** — загрузка, подготовка и обработка данных для нейросети.
- **`tests/`** — тестирование компонентов проекта.
- **`main.py`** — основная точка входа в приложение.

## Установка и запуск

### Требования

- Git
- [uv](https://docs.astral.sh/uv/getting-started/installation/)
- Make (необязательно)

### Установка

Клонирование репозитория:

```bash
git clone <URL_репозитория>
cd photonic_model
```

Установка зависимостей:

```bash
uv sync
```

`uv` автоматически создаст виртуальное окружение `.venv` и установит необходимые зависимости.
Для первых запусков используйте `uv sync --frozen --group dev` — причина в разделе
[«Первые запуски»](#первые-запуски-на-готовом-датасете).

### Запуск

```bash
uv run project
```

Или через Make:

```bash
make run
```

`project` открывает терминал проекта: справку по командам для готовых наборов данных,
baseline-синтеза и веб-интерфейса. Пошагово — в разделе
[«Первые запуски на готовом датасете»](#первые-запуски-на-готовом-датасете).

## Первые запуски на готовом датасете

Все команды выполняются из корня проекта. Нужны только `uv` и интернет для первой установки.

**0. Окружение (один раз).**

```bash
uv sync --frozen --group dev
```

Флаг `--frozen` важен: `uv.lock` собран для Python ≥ 3.14, а `pyproject.toml` допускает ≥ 3.11,
поэтому без флага `uv sync` и `uv run` перепишут `uv.lock` и в Git появится лишнее изменение.
Первая установка скачивает PyTorch; на Linux вместе с CUDA-библиотеками это несколько гигабайт.

**1. Проверить, что готовые наборы читаются** (Soft600: 3204 PNG, старый набор: 4804 PNG):

```bash
uv run --frozen project datasets --verify
```

**2. Один расчёт** — baseline Герчберга–Сэкстона на диагностической четвёрке
(200 итераций, seed 42, CPU):

```bash
uv run --frozen project run
```

Команда печатает метрики четырёх плоскостей и кладёт файлы запуска (`doe.png`,
`recon_1.png`…`recon_4.png`, `metrics.json`, `parameters.json`, `panel.png`, журнал)
в `demo-runs/run_…/`. Другой пример: `--sample soft1_train_000002` или
`--dataset old1000 --sample train_000001`; идентификаторы показывает
`uv run --frozen project samples --split train --limit 10`.

**3. Пакетный прогон по split** — ориентир, который должна превзойти нейросеть:

```bash
uv run --frozen project batch --limit 8
uv run --frozen project batch --split validation --all --out runs/baseline_validation
```

Результат: `summary.csv` (id и метрики названы как в CSV команды `doe-eval evaluate`,
плюс колонка `kind`), `batch.json`, `doe/<id>.png` и папка запуска на каждый пример.
Группы Soft600 (`physical_forward`, `soft_independent`) считаются отдельно, как требует
[SOFT600.md](src/dataset/SOFT600.md). Split `test` не используйте для подбора настроек —
только для финального сравнения.

**4. Веб-интерфейс** (`http://127.0.0.1:8765`):

```bash
uv run --frozen project serve --open
```

Кнопка «Загрузить пример» подставляет `diagnostic_0000`. Запуски из терминала (`run`) видны во вкладке
«История запусков» после (пере)запуска сервера: он читает `demo-runs/` при старте. На macOS сервер
можно открыть двойным щелчком по `Открыть демо.command`. Подробности демо — в [README_DEMO.md](README_DEMO.md).

**5. Нейросеть Захара** (`HoloUnrollNet`, чекпоинт `model_zakha.pt`). Весов в git нет: файл больше 50 МБ,
и ветка `zakhar_sandbox` убрала его из дерева. Возьмите его у Захара или достаньте из истории той ветки
(коммит `4bc2fb8fa`, путь `checkpoints/zakhar_5208_50epochs/best_model.pt`). Проверьте sha256 файла:
`2446a10393de734cae623b222d5558b40820fe25f7a3c9b31dbe41a19ff02faa`. Веса в репозиторий не коммитятся
(`*.pt` в `.gitignore`).

```bash
uv run --frozen project run --method neural --weights ПУТЬ/model_zakha.pt
```
```bash
uv run --frozen project batch --method neural --weights ПУТЬ/model_zakha.pt --split validation --all
```

Нейросеть и baseline идут через один адаптер: тот же 8-битный `doe.png`, тот же расчёт Френеля и те же
метрики, поэтому числа сопоставимы. После сети по умолчанию делается доработка фазы (`--polish-steps 25`,
как в `predict` Захара; `0` — только сеть). На GPU добавьте `--device cuda`. Архитектура и физика, с которыми
обучена модель, лежат копией в `src/model/zakhar/` (источник и хеши исходных файлов — в `__init__.py`).
Проверка на настоящем файле:
`WHITECOLLARS_ZAKHAR_WEIGHTS=ПУТЬ/model_zakha.pt uv run --frozen pytest src/tests/test_neural.py`.

### PyCharm

1. **File → Open** → корень репозитория (папка с `pyproject.toml`).
2. В терминале PyCharm (Alt+F12): `uv sync --frozen --group dev`.
3. **Settings → Project → Python Interpreter → Add Interpreter → Add Local Interpreter**, выбрать
   существующий (Existing): `.venv/bin/python` (Windows: `.venv\Scripts\python.exe`).
4. Правый клик на `src` → **Mark Directory as → Sources Root** (редактор увидит `app`, `doe_eval`, `model`).
5. Запуск из IDE: **Run → Edit Configurations → + → Python**; вместо «Script path» выбрать
   «Module name» = `app`, Parameters = `run --sample soft1_train_000002`, Working directory = корень
   проекта. Те же команды можно выполнять в терминале PyCharm.
6. Тесты: **Settings → Tools → Python Integrated Tools → Default test runner: pytest**,
   затем правый клик на `src/tests` → Run.

Ограничение: нейросеть запускается только из терминала, веб-интерфейс пока умеет только baseline GS.

## Разработка

### Управление зависимостями

Добавление зависимости:

```bash
uv add <название_пакета>
```

Добавление зависимости для разработки:

```bash
uv add --dev <название_пакета>
```

Удаление зависимости:

```bash
uv remove <название_пакета>
```

Синхронизация зависимостей:

```bash
uv sync
```

Зависимости проекта описываются в `pyproject.toml`, а их точные версии фиксируются в `uv.lock`.

При изменении зависимостей необходимо сохранять изменения обоих файлов в Git.

### Makefile

Для автоматизации основных операций используется `Makefile`.

Содержимое:

```makefile
install:
	uv sync

run:
	uv run project

test:
	uv run pytest src/tests

lint:
	uv run ruff check src

format:
	uv run ruff format src

build:
	uv build

clean:
	rm -rf build/ dist/
	find src -type d \( -name __pycache__ -o -name "*.egg-info" \) -prune -exec rm -rf {} +
```

**Доступные команды:**

| Команда | Описание |
|---|---|
| `make install` | Устанавливает и синхронизирует зависимости |
| `make run` | Запускает приложение |
| `make test` | Запускает тесты через pytest |
| `make lint` | Проверяет код с помощью Ruff |
| `make format` | Форматирует код с помощью Ruff |
| `make build` | Собирает Python-пакет |
| `make clean` | Удаляет результаты сборки и временные файлы |

Для команд `make test`, `make lint` и `make format` необходимы установленные `pytest` и `ruff`.

Все команды выполняются из корневой директории проекта.

## Датасет и аудит

**Новый пакет [Soft600](src/dataset/SOFT600.md): 600 train / 100 validation / 100 test**.
Мягкие цели, контролируемые дефекты и отдельная группа из физического моделирования.
Манифест: `src/dataset/data_soft600/manifest.json`; порядок подключения и ограничения —
в инструкции выше. Старый набор ниже сохранён для сравнения.

Готовый набор: **1000 обучающих + 100 валидационных + 100 тестовых четвёрок**,
плюс отдельная диагностика. Загрузчик получает `src/dataset/data/manifest.json`.
Генератор, команды воспроизведения и правила проверки описаны в
[src/dataset/README.md](src/dataset/README.md).
Результаты и ограничения текущего набора — в
[отчёте аудита](src/dataset/audit_report/SUMMARY.md).
