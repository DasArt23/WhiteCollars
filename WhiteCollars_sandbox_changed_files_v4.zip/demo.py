"""Run from a source checkout, including paths containing non-ASCII characters."""
import os
import sys
from pathlib import Path

source = str(Path(__file__).resolve().parent / 'src')
sys.path.insert(0, source)
os.environ['PYTHONPATH'] = source + (os.pathsep + os.environ['PYTHONPATH'] if os.environ.get('PYTHONPATH') else '')

from app.__main__ import main

if __name__ == '__main__':
    main()
