#!/bin/zsh
cd "${0:A:h}"
if [[ ! -x .venv/bin/python ]]; then
  print 'Сначала установите окружение: uv sync --frozen'
  read -k 1 '?Нажмите любую клавишу для выхода…'
  exit 1
fi
exec .venv/bin/python demo.py --open
