"""Загрузка чекпоинта HoloUnrollNet в формате Захара.

Повторяет ``load_trained_holonet`` из его ``src/main.py``: ``torch.load(weights_only=True)``
(pickle не исполняется), ``state_dict`` + метаданные архитектуры, строгая загрузка весов.
Отличие одно: любая ошибка чтения превращается в ``ValueError`` с понятным текстом.
"""
from __future__ import annotations

from functools import lru_cache
from pathlib import Path
from typing import Any

import torch

from .holonet import HoloUnrollNet


def load_trained_holonet(
    checkpoint_path: str | Path,
    device: str | torch.device = "cpu",
) -> tuple[HoloUnrollNet, torch.device, dict[str, Any]]:
    path = Path(checkpoint_path)
    if not path.is_file():
        raise FileNotFoundError(f"Чекпоинт не найден: {path}")
    dev = torch.device(device)
    try:
        payload = torch.load(path, map_location=dev, weights_only=True)
    except Exception as exc:  # любой сбой чтения = «это не чекпоинт»; ошибка перевыбрасывается
        raise ValueError(
            f"{path}: не удалось прочитать чекпоинт ({type(exc).__name__}). "
            "Нужен файл PyTorch с весами HoloUnrollNet."
        ) from exc
    if not isinstance(payload, dict):
        raise ValueError(f"{path}: ожидался словарь с весами, получен {type(payload).__name__}")  # noqa: TRY004 - вызывающий код ловит ValueError

    meta: dict[str, Any] = {"checkpoint": str(path)}
    unroll_steps, base_dim = 6, 48
    equalize_plane_power, phase_carrier_seed = False, None  # значения для старых чекпоинтов
    if "state_dict" in payload:
        unroll_steps = int(payload.get("unroll_steps", 6))
        base_dim = int(payload.get("base_dim", 48))
        equalize_plane_power = bool(payload.get("equalize_plane_power", False))
        phase_carrier_seed = payload.get("phase_carrier_seed")
        state_dict = payload["state_dict"]
        meta["epoch"] = payload.get("epoch")
    else:
        state_dict = payload  # «голый» state_dict

    try:
        model = HoloUnrollNet(
            unroll_steps=unroll_steps,
            base_dim=base_dim,
            equalize_plane_power=equalize_plane_power,
            phase_carrier_seed=phase_carrier_seed,
        ).to(dev)
        model.load_state_dict(state_dict, strict=True)
    except (RuntimeError, ValueError, TypeError) as exc:
        raise ValueError(
            f"{path}: веса не подходят к архитектуре HoloUnrollNet "
            f"(unroll_steps={unroll_steps}, base_dim={base_dim}): {str(exc).splitlines()[0]}"
        ) from exc
    model.eval()
    meta.update(
        unroll_steps=unroll_steps,
        base_dim=base_dim,
        equalize_plane_power=equalize_plane_power,
        phase_carrier_seed=phase_carrier_seed,
        parameters=sum(p.numel() for p in model.parameters()),
    )
    return model, dev, meta


@lru_cache(maxsize=2)
def _load_cached(path: str, mtime_ns: int, size: int, device: str):
    # mtime и размер входят в ключ: подменённый файл не вернёт старую модель из кэша.
    model, _, meta = load_trained_holonet(path, device)
    return model, meta


def get_model(checkpoint_path: str | Path, device: str | torch.device = "cpu"):
    """Модель и метаданные с кэшем: пакетный прогон загружает веса один раз."""
    path = Path(checkpoint_path).resolve()
    stat = path.stat()
    dev = torch.device(device)
    if dev.type == "cuda" and dev.index is None:
        dev = torch.device("cuda", torch.cuda.current_device())  # 'cuda' и 'cuda:0' - один ключ кэша
    return _load_cached(str(path), stat.st_mtime_ns, stat.st_size, str(dev))
