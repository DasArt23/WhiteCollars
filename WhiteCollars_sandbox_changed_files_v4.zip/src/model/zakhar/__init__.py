"""HoloUnrollNet Захара: архитектура и физика, с которыми обучен чекпоинт.

Источник: ветка ``zakhar_sandbox``, коммит ``9aac288b0`` (автор fen1x).

    holonet.py  <- src/model/holonet.py        sha256 86ad78b02750f596...
    physics.py  <- src/doe_eval/physics.py     sha256 6ee1ec3eb52dbd9e...
    metrics.py  <- src/doe_eval/metrics.py     sha256 969ec502f2fb65d8...

Три файла скопированы дословно, изменены только строки импорта: относительные
``.physics`` / ``.metrics`` вместо ``doe_eval.*``. Общий ``doe_eval`` при этом не
тронут: у Захара ``fresnel_propagate_complex``, ``ste_quantize``, ``pearson_torch``
и ``ssim_global_torch`` отличаются от наших, а модель обучена именно с его версиями.
Оценка результата в терминале и в веб-интерфейсе по-прежнему идёт общим кодом
``doe_eval`` (одна физика и одни метрики для baseline и нейросети).

После слияния веток эту копию можно заменить общим ``doe_eval``.
``loader.py`` написан здесь: он повторяет ``load_trained_holonet`` из его ``src/main.py``.
"""
from .holonet import HoloUnrollNet, hybrid_infer_phase
from .loader import get_model, load_trained_holonet

__all__ = ["HoloUnrollNet", "get_model", "hybrid_infer_phase", "load_trained_holonet"]
