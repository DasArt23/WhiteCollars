"""Нейросетевой режим терминала (HoloUnrollNet, чекпоинт Захара).

Реальные веса (~80 МБ) в репозитории не лежат, поэтому тесты строят крошечную модель
в том же формате чекпоинта. Проверка на настоящем файле включается переменной
``WHITECOLLARS_ZAKHAR_WEIGHTS`` (и необязательной ``WHITECOLLARS_ZAKHAR_DEVICE=cuda``).
"""
from __future__ import annotations

import csv
import hashlib
import json
import os
from pathlib import Path

import pytest
import torch
from PIL import Image

from app import jobs, terminal
from model.zakhar import HoloUnrollNet, load_trained_holonet
from model.zakhar import loader as zakhar_loader


def checkpoint(path: Path, base_dim: int = 8, meta_base_dim: int | None = None, **extra) -> Path:
    torch.manual_seed(0)
    net = HoloUnrollNet(unroll_steps=1, base_dim=base_dim, equalize_plane_power=True, phase_carrier_seed=3701)
    torch.save({'state_dict': net.state_dict(), 'unroll_steps': 1, 'base_dim': meta_base_dim or base_dim,
                'equalize_plane_power': True, 'phase_carrier_seed': 3701, 'epoch': 1, **extra}, path)
    return path


@pytest.fixture(scope='module')
def tiny_weights(tmp_path_factory):
    return checkpoint(tmp_path_factory.mktemp('weights') / 'tiny.pt')


@pytest.fixture
def runs(tmp_path, monkeypatch):
    monkeypatch.setattr(jobs, 'RUNS', tmp_path / 'runs')
    monkeypatch.setattr(jobs, 'UPLOADS', tmp_path / 'uploads')
    return tmp_path / 'runs'


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def test_loader_reads_the_checkpoint_format(tiny_weights):
    model, device, meta = load_trained_holonet(tiny_weights, 'cpu')
    assert device.type == 'cpu' and not model.training
    assert (meta['unroll_steps'], meta['base_dim'], meta['equalize_plane_power']) == (1, 8, True)
    assert (meta['phase_carrier_seed'], meta['epoch']) == (3701, 1)
    assert meta['parameters'] == sum(p.numel() for p in model.parameters()) > 0


def test_loader_errors_are_readable_and_never_execute_the_file(tmp_path, tiny_weights):
    with pytest.raises(FileNotFoundError):
        load_trained_holonet(tmp_path / 'missing.pt')
    garbage = tmp_path / 'garbage.pt'
    garbage.write_bytes(b'this is not a checkpoint')
    with pytest.raises(ValueError, match='не удалось прочитать'):
        load_trained_holonet(garbage)
    mismatch = checkpoint(tmp_path / 'mismatch.pt', base_dim=8, meta_base_dim=16)
    with pytest.raises(ValueError, match='не подходят к архитектуре'):
        load_trained_holonet(mismatch)
    # Вредоносный pickle: weights_only=True обязан отказать, а код из файла не выполняется.
    marker = tmp_path / 'executed.txt'

    class Evil:
        def __reduce__(self):
            return eval, (f"__import__('pathlib').Path({str(marker)!r}).write_text('x')",)

    evil = tmp_path / 'evil.pt'
    torch.save({'state_dict': {}, 'payload': Evil()}, evil)
    with pytest.raises(ValueError, match='не удалось прочитать'):
        load_trained_holonet(evil)
    assert not marker.exists()


def test_neural_run_writes_the_shared_artifacts_and_provenance(runs, tmp_path, tiny_weights):
    out = tmp_path / 'neural'
    argv = ['run', '--method', 'neural', '--weights', str(tiny_weights), '--polish-steps', '2', '--out', str(out)]
    assert terminal.main(argv) == 0
    for name in ('doe.png', 'recon_1.png', 'recon_2.png', 'recon_3.png', 'recon_4.png', 'metrics.json',
                 'panel.png', 'parameters.json', 'events.jsonl', 'run.log'):
        assert (out / name).is_file(), name
    with Image.open(out / 'doe.png') as doe:
        assert (doe.mode, doe.size) == ('L', (128, 128))
    report = json.loads((out / 'metrics.json').read_text())
    assert len(report['planes']) == 4 and report['method'] == 'neural' and report['polish_steps'] == 2
    assert 'iters' not in report
    meta = json.loads((out / 'parameters.json').read_text())
    assert meta['status'] == 'completed' and meta['method'] == 'neural'
    assert meta['config']['method'] == 'neural' and meta['config']['polish_steps'] == 2
    assert meta['weights']['sha256'] == sha256(tiny_weights)
    assert meta['weights']['size_bytes'] == tiny_weights.stat().st_size
    assert meta['weights']['model']['unroll_steps'] == 1 and meta['weights']['model']['epoch'] == 1
    assert meta['timing']['weights_s'] > 0 and meta['timing']['synthesis_s'] > 0


def test_neural_runs_are_deterministic_and_listed_by_the_web_history(runs, tiny_weights):
    argv = ['run', '--method', 'neural', '--weights', str(tiny_weights), '--polish-steps', '1']
    assert terminal.main(argv) == 0 and terminal.main(argv) == 0
    first, second = sorted(runs.iterdir())
    assert (first / 'doe.png').read_bytes() == (second / 'doe.png').read_bytes()
    manager = jobs.JobManager()
    history = manager.history()
    assert len(history) == 2 and {item['method'] for item in history} == {'neural'}
    snap = manager.snapshot(history[0]['id'])
    assert snap['metadata']['status'] == 'completed' and len(snap['metrics']['planes']) == 4


def test_neural_batch_loads_weights_once_and_records_them(tmp_path, tiny_weights, monkeypatch):
    zakhar_loader._load_cached.cache_clear()
    calls = []
    real = zakhar_loader.load_trained_holonet
    monkeypatch.setattr(zakhar_loader, 'load_trained_holonet', lambda *a, **k: calls.append(a) or real(*a, **k))
    out = tmp_path / 'batch'
    argv = ['batch', '--method', 'neural', '--weights', str(tiny_weights), '--polish-steps', '0',
            '--split', 'validation', '--limit', '2', '--out', str(out)]
    assert terminal.main(argv) == 0
    assert len(calls) == 1
    rows = list(csv.DictReader((out / 'summary.csv').open(encoding='utf-8')))
    assert [r['id'] for r in rows] == ['soft1_validation_000001', 'soft1_validation_000002']
    batch = json.loads((out / 'batch.json').read_text())
    assert batch['config']['method'] == 'neural' and batch['failed'] == []
    assert batch['weights']['sha256'] == sha256(tiny_weights)
    assert all((out / 'doe' / f'{r["id"]}.png').is_file() for r in rows)


def test_baseline_configuration_is_unchanged_by_neural_support():
    args = terminal.build_parser().parse_args(['run'])
    assert terminal.make_config(args) == {'iters': 200, 'seed': 42, 'device': 'cpu', 'norm': 'max', 'compare': 'amplitude'}


def test_neural_option_mistakes_give_short_messages(runs, tmp_path, tiny_weights, capsys):
    garbage = tmp_path / 'garbage.pt'
    garbage.write_bytes(b'not a checkpoint')
    for argv in (
        ['run', '--method', 'neural'],
        ['run', '--method', 'neural', '--weights', str(tmp_path / 'missing.pt')],
        ['run', '--weights', str(tiny_weights)],
        ['run', '--method', 'neural', '--weights', str(tiny_weights), '--polish-steps', '999'],
        ['run', '--method', 'neural', '--weights', str(garbage)],
    ):
        assert terminal.main(argv) == 2, argv
    err = capsys.readouterr().err
    assert 'требует --weights' in err and 'не найден' in err and 'только вместе с --method neural' in err
    assert '--polish-steps' in err and 'не удалось прочитать' in err and 'Traceback' not in err


@pytest.mark.skipif(not os.environ.get('WHITECOLLARS_ZAKHAR_WEIGHTS'),
                    reason='задайте WHITECOLLARS_ZAKHAR_WEIGHTS=путь к model_zakha.pt')
def test_real_weights_smoke(runs, tmp_path):
    out = tmp_path / 'real'
    argv = ['run', '--method', 'neural', '--weights', os.environ['WHITECOLLARS_ZAKHAR_WEIGHTS'],
            '--device', os.environ.get('WHITECOLLARS_ZAKHAR_DEVICE', 'cpu'), '--out', str(out)]
    assert terminal.main(argv) == 0
    report = json.loads((out / 'metrics.json').read_text())
    assert report['mean']['pearson'] > 0.4 and report['mean']['ssim_global'] > 0.2
    meta = json.loads((out / 'parameters.json').read_text())
    assert meta['weights']['model']['unroll_steps'] >= 1 and len(meta['weights']['sha256']) == 64
