"""Behavior/provenance checks against the real scientific path, no fake model."""
from __future__ import annotations

import base64
import hashlib
import json
import subprocess
import sys
import time

import numpy as np
import pytest
from PIL import Image

from app import jobs
from app.adapter import ROOT, diagnostic_paths


@pytest.fixture
def manager(tmp_path, monkeypatch):
    monkeypatch.setattr(jobs,'RUNS',tmp_path/'runs')
    monkeypatch.setattr(jobs,'UPLOADS',tmp_path/'uploads')
    return jobs.JobManager()


def wait(manager, run_id):
    deadline=time.monotonic()+30
    while time.monotonic()<deadline:
        result=manager.snapshot(run_id)
        if result['metadata']['status'] in jobs.TERMINAL:
            return result
        time.sleep(.05)
    pytest.fail('Background calculation did not complete in 30 seconds')


def test_upload_strict_validation_and_order(manager,tmp_path):
    for mode,size in [('RGB',(128,128)),('L',(64,64)),('I;16',(128,128))]:
        p=tmp_path/'bad.png';Image.new(mode,size).save(p)
        with pytest.raises(ValueError):
            manager.upload({'name':'bad.png','data':base64.b64encode(p.read_bytes()).decode()})
    p=tmp_path/'blank.png';Image.new('L',(128,128),0).save(p)
    with pytest.raises(ValueError,match='фон'):
        manager.upload({'data':base64.b64encode(p.read_bytes()).decode()})
    example=manager.example()
    _,sources=diagnostic_paths()
    for f,source in zip(example['files'],sources):
        assert (jobs.UPLOADS/f'{f["token"]}.png').read_bytes()==source.read_bytes()
    with pytest.raises(ValueError,match='четыре'):
        manager.start({'files':example['files'][:3],'method':'baseline'})
    with pytest.raises(ValueError,match='Neural'):
        manager.start({'files':example['files'],'method':'neural'})


def test_real_run_cli_equivalence_and_immutable_snapshot(manager,tmp_path):
    files=manager.example()['files']
    config={'method':'baseline','files':files,'iters':5,'seed':42,'device':'cpu'}
    result=manager.start(config);run_id=result['metadata']['id'];folder=jobs.RUNS/run_id
    hashes=[hashlib.sha256((folder/f'input_{i:02}.png').read_bytes()).hexdigest() for i in range(1,5)]
    # Subsequent form/upload changes cannot affect the launch snapshot.
    (jobs.UPLOADS/f'{files[0]["token"]}.png').write_bytes(b'changed after start')
    done=wait(manager,run_id)
    assert done['metadata']['status']=='completed',done['logs']
    assert all(h==record['sha256'] for h,record in zip(hashes,done['metadata']['inputs']))
    assert all(hashlib.sha256((folder/f'input_{i:02}.png').read_bytes()).hexdigest()==h for i,h in enumerate(hashes,1))
    report=json.loads((folder/'metrics.json').read_text())
    assert done['metrics']==report
    assert report['minimum']['pearson']==min(row['pearson'] for row in report['planes'])
    assert report['mean']['ssim_global']==float(np.mean([r['ssim_global'] for r in report['planes']]))
    cli=tmp_path/'cli'
    subprocess.run([sys.executable,str(ROOT/'demo.py'),'--cli','--inputs',*[str(folder/f'input_{i:02}.png') for i in range(1,5)],'--out',str(cli),'--iters','5'],check=True,capture_output=True,text=True)
    assert json.loads((cli/'metrics.json').read_text())==report
    for name in ('doe.png','recon_1.png','recon_2.png','recon_3.png','recon_4.png'):
        assert (folder/name).read_bytes()==(cli/name).read_bytes()
    assert done['metadata']['timing']['synthesis_s']>0
    assert done['metadata']['timing']['total_s']>=done['metadata']['timing']['synthesis_s']
    assert {r['source'] for r in done['logs']}=={'app','adapter'}


def test_cancellation_single_job_and_independent_runs(manager):
    files=manager.example()['files']
    first=manager.start({'method':'baseline','files':files,'iters':5000})
    with pytest.raises(RuntimeError,match='выполняется'):
        manager.start({'method':'baseline','files':files,'iters':1})
    manager.cancel(first['metadata']['id'])
    cancelled=wait(manager,first['metadata']['id'])
    assert cancelled['metadata']['status']=='cancelled'
    assert cancelled['metrics'] is None
    second=manager.start({'method':'baseline','files':files,'iters':2})
    done=wait(manager,second['metadata']['id'])
    assert done['metadata']['status']=='completed'
    assert second['metadata']['id']!=first['metadata']['id']
    assert len(manager.history())==2
    restored=jobs.JobManager()
    assert restored.snapshot(first['metadata']['id'])['metadata']['status']=='cancelled'
    assert restored.snapshot(second['metadata']['id'])['metrics']==done['metrics']


@pytest.mark.parametrize('damage',['missing_png','bad_json'])
def test_damaged_artifacts_cannot_appear_successful(manager,damage):
    files=manager.example()['files']
    started=manager.start({'method':'baseline','files':files,'iters':2})
    run_id=started['metadata']['id']
    assert wait(manager,run_id)['metadata']['status']=='completed'
    folder=jobs.RUNS/run_id
    if damage=='missing_png':
        (folder/'recon_2.png').unlink()
    else:
        (folder/'metrics.json').write_text('{broken')
    bad=manager.snapshot(run_id)
    assert bad['metadata']['status']=='error'
    assert bad['metrics'] is None
    assert json.loads((folder/'parameters.json').read_text())['status']=='error'
