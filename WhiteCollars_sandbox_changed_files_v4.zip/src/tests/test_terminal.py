"""Терминальный интерфейс: те же расчёт и файлы, что у веб-интерфейса. Нейросеть не имитируется."""
from __future__ import annotations

import csv
import json
import shutil
import subprocess
import sys

import pytest
import torch
from PIL import Image

from app import jobs, terminal
from app.__main__ import TERMINAL_COMMANDS
from app.adapter import ROOT, diagnostic_paths
from doe_eval.cli import evaluate_pair_arrays, reconstruct_from_doe_file
from doe_eval.io import load_four_targets

SOFT = ROOT / 'src/dataset/data_soft600/manifest.json'
OLD = ROOT / 'src/dataset/data/manifest.json'
PNG_NAMES = ('doe.png', 'recon_1.png', 'recon_2.png', 'recon_3.png', 'recon_4.png')


@pytest.fixture
def runs(tmp_path, monkeypatch):
    monkeypatch.setattr(jobs, 'RUNS', tmp_path / 'runs')
    monkeypatch.setattr(jobs, 'UPLOADS', tmp_path / 'uploads')
    return tmp_path / 'runs'


def manifest_samples(path, **match):
    raw = json.loads(path.read_text(encoding='utf-8'))
    return [
        s for s in raw['samples']
        if all((s.get(k) if k == 'split' else s['params'].get(k)) == v for k, v in match.items())
    ]


def test_dispatcher_and_parser_know_the_same_commands():
    assert set(TERMINAL_COMMANDS) == set(terminal.COMMANDS)
    for name in terminal.COMMANDS:
        with pytest.raises(SystemExit) as stop:
            terminal.main([name, '--help'])
        assert stop.value.code == 0


def test_project_entry_point_starts_terminal(monkeypatch, capsys):
    import main  # src/main.py, [project.scripts] project = "main:main"
    monkeypatch.setattr(sys, 'argv', ['project', 'datasets', '--dataset', 'soft600'])
    assert main.main() == 0
    assert 'soft600' in capsys.readouterr().out
    monkeypatch.setattr(sys, 'argv', ['project'])
    assert main.main() == 0
    assert 'Первые запуски' in capsys.readouterr().out


def test_datasets_describe_both_shipped_manifests(capsys):
    assert terminal.main(['datasets']) == 0
    out = capsys.readouterr().out
    assert 'soft600' in out and 'old1000' in out
    assert 'train 600 (physical_forward 240, soft_independent 360)' in out
    assert 'train 1000' in out and 'diagnostic 1' in out


def test_samples_filter_by_split_and_kind(capsys):
    expected = [s['sample_id'] for s in manifest_samples(SOFT, split='test', kind='physical_forward')][:3]
    assert terminal.main(['samples', '--split', 'test', '--kind', 'physical_forward', '--limit', '3']) == 0
    lines = capsys.readouterr().out.splitlines()
    assert [line.split()[1] for line in lines[1:]] == expected
    assert all(line.endswith('physical_forward') for line in lines[1:])


def test_run_gives_the_same_files_as_the_demo_cli(runs, tmp_path):
    out = tmp_path / 'terminal'
    assert terminal.main(['run', '--iters', '3', '--out', str(out)]) == 0
    _, sources = diagnostic_paths()
    legacy = tmp_path / 'legacy'
    subprocess.run(
        [sys.executable, str(ROOT / 'demo.py'), '--cli', '--inputs', *map(str, sources),
         '--out', str(legacy), '--iters', '3'],
        check=True, capture_output=True, text=True,
    )
    assert json.loads((out / 'metrics.json').read_text()) == json.loads((legacy / 'metrics.json').read_text())
    for name in PNG_NAMES:
        assert (out / name).read_bytes() == (legacy / name).read_bytes()
    meta = json.loads((out / 'parameters.json').read_text())
    assert meta['status'] == 'completed'
    assert meta['source']['sample_id'] == 'diagnostic_0000'
    assert meta['source']['manifest'] == 'src/dataset/data_soft600/manifest.json'


def test_single_run_is_visible_in_the_web_history(runs):
    assert terminal.main(['run', '--sample', 'soft1_train_000002', '--iters', '2']) == 0
    manager = jobs.JobManager()  # так сервер читает demo-runs/ при старте
    [item] = manager.history()
    assert item['status'] == 'completed'
    assert item['source']['sample_id'] == 'soft1_train_000002'
    snap = manager.snapshot(item['id'])
    assert snap['metadata']['status'] == 'completed'
    assert len(snap['metrics']['planes']) == 4
    assert snap['logs'] and {r['source'] for r in snap['logs']} == {'adapter'}
    assert {'doe.png', 'metrics.json', 'panel.png', 'events.jsonl', 'run.log'} <= set(snap['artifacts'])


def test_batch_writes_summary_predictions_and_groups(runs, tmp_path):
    out = tmp_path / 'batch'
    argv = ['batch', '--split', 'validation', '--limit', '2', '--iters', '2', '--out', str(out)]
    assert terminal.main(argv) == 0
    rows = list(csv.DictReader((out / 'summary.csv').open(encoding='utf-8')))
    assert [r['id'] for r in rows] == ['soft1_validation_000001', 'soft1_validation_000002']
    assert [r['kind'] for r in rows] == ['physical_forward', 'soft_independent']
    assert list(rows[0])[:5] == ['id', 'kind', 'pearson_mean', 'ssim_global_mean', 'ssim_skimage_mean']
    for r in rows:
        assert (out / 'doe' / f'{r["id"]}.png').read_bytes() == (out / r['id'] / 'doe.png').read_bytes()
    batch = json.loads((out / 'batch.json').read_text())
    assert batch['failed'] == [] and set(batch['mean_by_kind']) == {'physical_forward', 'soft_independent'}
    assert batch['mean']['pearson'] == pytest.approx(sum(float(r['pearson_mean']) for r in rows) / 2)

    # doe/<id>.png - тот же формат, что у export_split_predictions: оценка проектным кодом даёт те же метрики.
    data = terminal.load_dataset('soft600')
    sample = next(s for s in data.samples if s.sample_id == rows[0]['id'])
    targets = load_four_targets([data.root_dir / rel for rel in sample.images])
    recons = reconstruct_from_doe_file(out / 'doe' / f'{sample.sample_id}.png', torch.device('cpu'), 'max', 'amplitude')
    again = evaluate_pair_arrays(targets, recons)
    saved = json.loads((out / sample.sample_id / 'metrics.json').read_text())
    assert again['mean'] == pytest.approx(saved['mean'], rel=1e-9)

    # Результаты не перезаписываются.
    before = (out / 'summary.csv').read_bytes()
    assert terminal.main(argv) == 2
    assert (out / 'summary.csv').read_bytes() == before


def test_batch_keeps_going_after_a_bad_sample(tmp_path):
    raw = json.loads(SOFT.read_text(encoding='utf-8'))
    picked = [s for s in raw['samples'] if s['split'] == 'validation'][:2]
    root = tmp_path / 'mini'
    for s in picked:
        for rel in s['images']:
            (root / rel).parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(SOFT.parent / rel, root / rel)
    raw['samples'] = picked
    (root / 'manifest.json').write_text(json.dumps(raw), encoding='utf-8')
    Image.new('RGB', (128, 128), 'white').save(root / picked[1]['images'][1])  # цветной PNG нарушает контракт

    out = tmp_path / 'out'
    code = terminal.main(['batch', '--dataset', str(root / 'manifest.json'), '--split', 'validation',
                          '--iters', '2', '--out', str(out)])
    assert code == 1
    batch = json.loads((out / 'batch.json').read_text())
    assert [r['id'] for r in batch['samples']] == [picked[0]['sample_id']]
    assert [f['id'] for f in batch['failed']] == [picked[1]['sample_id']]
    assert not (out / picked[1]['sample_id']).exists()  # плохой вход не оставил папку запуска


def test_mistakes_give_short_messages_not_tracebacks(runs, tmp_path, capsys):
    existing = tmp_path / 'already_here'
    existing.mkdir()
    for argv in (
        ['run', '--sample', 'no_such_sample'],
        ['run', '--dataset', 'nope'],
        ['run', '--iters', '0'],
        ['run', '--index', '5'],
        ['run', '--out', str(existing)],
        ['batch', '--kind', 'physical_forward', '--dataset', 'old1000'],  # в старом наборе групп нет
        ['batch', '--limit', '0'],
        ['batch', '--start', '-1'],
        ['samples', '--limit', '-3'],
    ):
        assert terminal.main(argv) == 2, argv
    err = capsys.readouterr().err
    assert 'no_such_sample' in err and "'nope'" in err and 'Traceback' not in err
    assert list(existing.iterdir()) == []
    assert not runs.exists() or list(runs.iterdir()) == []


def test_old_dataset_is_runnable_too(runs, tmp_path):
    first = manifest_samples(OLD, split='train')[0]['sample_id']
    out = tmp_path / 'old'
    assert terminal.main(['run', '--dataset', 'old1000', '--sample', first, '--iters', '2', '--out', str(out)]) == 0
    assert json.loads((out / 'parameters.json').read_text())['source']['sample_id'] == first
