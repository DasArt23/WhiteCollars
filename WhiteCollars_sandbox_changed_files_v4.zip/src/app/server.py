from __future__ import annotations

import io
import json
import mimetypes
import re
import webbrowser
import zipfile
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlsplit

import torch

from .adapter import ROOT, git_version
from .jobs import JobManager, RUNS, UPLOADS

STATIC = ROOT/'src/app/static'


def serve(host='127.0.0.1', port=8765, open_browser=False):
    jobs = JobManager()
    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *_):
            pass

        def respond(self, data, status=200, mime='application/json; charset=utf-8', attachment=None):
            raw = json.dumps(data, ensure_ascii=False, allow_nan=False).encode() if mime.startswith('application/json') else data
            self.send_response(status)
            self.send_header('Content-Type',mime)
            self.send_header('Content-Length',str(len(raw)))
            self.send_header('Cache-Control','no-store' if '/api/' in self.path else 'no-cache')
            self.send_header('X-Content-Type-Options','nosniff')
            self.send_header('Content-Security-Policy',"default-src 'self'; img-src 'self' blob: data:; style-src 'self'; script-src 'self'; font-src 'self'; frame-ancestors 'none'")
            if attachment:
                self.send_header('Content-Disposition',f'attachment; filename="{attachment}"')
            self.end_headers()
            self.wfile.write(raw)

        def do_GET(self):
            if self.headers.get('Host','') not in {f'127.0.0.1:{port}',f'localhost:{port}'}:
                return self.respond({'error':'Доступ разрешён только с локального интерфейса.'},403)
            path = urlsplit(self.path).path
            try:
                if path == '/api/status':
                    return self.respond({'server': 'online', 'version':git_version(), 'cuda':torch.cuda.is_available(), 'neural':False, 'neural_reason':'В ветке sandbox нет архитектуры и обученных весов.', 'active':jobs.active, 'result_root':str(RUNS)})
                if path == '/api/history':
                    return self.respond(jobs.history())
                match = re.fullmatch(r'/api/jobs/([a-zA-Z0-9_-]{1,100})', path)
                if match:
                    return self.respond(jobs.snapshot(match[1]))
                match = re.fullmatch(r'/api/uploads/([a-f0-9]{32})', path)
                if match:
                    return self.respond((UPLOADS/f'{match[1]}.png').read_bytes(),mime='image/png')
                match = re.fullmatch(r'/api/jobs/([a-zA-Z0-9_-]{1,100})/(files/([a-zA-Z0-9_.-]+)|archive)',path)
                if match:
                    run_id = match[1]
                    if run_id not in jobs.jobs:
                        raise KeyError(run_id)
                    folder = RUNS/run_id
                    if match[2] == 'archive':
                        if jobs.snapshot(run_id)['metadata']['status'] not in ('completed','error','cancelled'):
                            raise ValueError('Архив доступен после завершения или отмены.')
                        buff = io.BytesIO()
                        with zipfile.ZipFile(buff,'w',zipfile.ZIP_DEFLATED) as z:
                            for p in sorted(folder.iterdir()):
                                if p.is_file() and p.suffix != '.tmp':
                                    z.write(p,arcname=f'{run_id}/{p.name}')
                        return self.respond(buff.getvalue(),mime='application/zip',attachment=f'{run_id}.zip')
                    name = match[3]
                    allowed = {'parameters.json','metrics.json','run.log','events.jsonl','doe.png','panel.png'} | {f'input_{i:02}.png' for i in range(1,5)} | {f'recon_{i}.png' for i in range(1,5)}
                    if name not in allowed:
                        raise FileNotFoundError(name)
                    return self.respond((folder/name).read_bytes(),mime=mimetypes.guess_type(name)[0] or 'text/plain; charset=utf-8')
                local = STATIC / ('index.html' if path == '/' else path.lstrip('/'))
                if not local.resolve().is_relative_to(STATIC.resolve()) or not local.is_file():
                    raise FileNotFoundError(path)
                return self.respond(local.read_bytes(),mime=mimetypes.guess_type(local.name)[0] or 'application/octet-stream')
            except (KeyError, FileNotFoundError):
                self.respond({'error':'Файл или запуск не найден.'},404)
            except ValueError as exc:
                self.respond({'error':str(exc)},400)

        def do_POST(self):
            host_header = self.headers.get('Host','')
            expected = {f'127.0.0.1:{port}',f'localhost:{port}'}
            origin = self.headers.get('Origin')
            if host_header not in expected or (origin and origin not in {f'http://{h}' for h in expected}):
                return self.respond({'error':'Доступ разрешён только с локального интерфейса.'},403)
            try:
                size = int(self.headers.get('Content-Length','0'))
                if not 0 < size <= 2*1024*1024 or not self.headers.get('Content-Type','').startswith('application/json'):
                    raise ValueError('Ожидался JSON до 2 МБ.')
                data = json.loads(self.rfile.read(size))
                if not isinstance(data,dict):
                    raise ValueError('Ожидался объект JSON.')
                if self.path == '/api/uploads':
                    return self.respond(jobs.upload(data))
                if self.path == '/api/example':
                    return self.respond(jobs.example())
                if self.path == '/api/jobs':
                    return self.respond(jobs.start(data),201)
                match = re.fullmatch(r'/api/jobs/([a-zA-Z0-9_-]{1,100})/cancel',self.path)
                if match:
                    return self.respond(jobs.cancel(match[1]))
                return self.respond({'error':'Маршрут не найден.'},404)
            except RuntimeError as exc:
                self.respond({'error':str(exc)},409)
            except (ValueError, KeyError, OSError) as exc:
                self.respond({'error':str(exc)},400)

    server = ThreadingHTTPServer((host,port),Handler)
    print(f'WhiteCollars demo → http://{host}:{port}',flush=True)
    if open_browser:
        webbrowser.open(f'http://{host}:{port}')
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        if jobs.active:
            jobs.cancel(jobs.active)
    finally:
        server.server_close()
