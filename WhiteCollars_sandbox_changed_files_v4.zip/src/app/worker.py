from __future__ import annotations

import json
import sys
import traceback
from pathlib import Path

from .adapter import run_calculation, write_json


def main():
    folder = Path(sys.argv[1])
    meta = json.loads((folder/'parameters.json').read_text())
    def emit(event):
        print(json.dumps(event, ensure_ascii=False), flush=True)
    try:
        _, timing = run_calculation(folder, meta['config'], emit)
        meta.update(status='completed', timing=timing)
        write_json(folder/'parameters.json', meta)
        emit({'stage': 'completed', 'message': 'Расчёт завершён. Все четыре плоскости и фазовая маска сохранены.'})
    except Exception as exc:
        traceback.print_exc()
        meta.update(status='error', error=str(exc))
        write_json(folder/'parameters.json', meta)
        emit({'stage': 'error', 'message': str(exc)})
        sys.exit(1)


if __name__ == '__main__':
    main()
