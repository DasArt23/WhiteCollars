"""Терминальный интерфейс WhiteCollars.

Запуск: ``uv run --frozen project <команда>`` или ``python -m app <команда>``.

Все расчёты (baseline и нейросеть, ``--method``) идут через ``app.adapter.run_calculation`` -
ту же функцию вызывают фоновый процесс веб-интерфейса и ``python -m app --cli``. Поэтому файлы запуска
(``doe.png``, ``recon_N.png``, ``metrics.json``, ``parameters.json`` ...) устроены
одинаково, а одиночные запуски из терминала лежат в ``demo-runs/`` и видны
в «Истории запусков» веб-интерфейса.

Готовые наборы берутся через ``model.load_manifest`` - тот же загрузчик,
которым будет пользоваться обучение.
"""
from __future__ import annotations

import argparse
import csv
import json
import shutil
import sys
import uuid
from datetime import UTC, datetime
from pathlib import Path

import numpy as np
import torch

from . import jobs, neural
from .adapter import (
    ROOT,
    git_version,
    metadata,
    run_calculation,
    validate_target,
    write_json,
)

DATASETS = {
    'soft600': ROOT / 'src/dataset/data_soft600/manifest.json',
    'old1000': ROOT / 'src/dataset/data/manifest.json',
}
DEFAULT_DATASET = 'soft600'
COMMANDS = ('datasets', 'samples', 'run', 'batch', 'serve')
METRICS = ('pearson', 'ssim_global', 'ssim_skimage')

EXAMPLES = """\
Первые запуски (из корня проекта):
  uv run --frozen project datasets --verify   проверить, что готовые наборы читаются
  uv run --frozen project run                 baseline на диагностической четвёрке
  uv run --frozen project batch --limit 8     baseline на 8 примерах validation
  uv run --frozen project run --method neural --weights model_zakha.pt   нейросеть Захара
  uv run --frozen project serve --open        веб-интерфейс в браузере

Набор: --dataset soft600 (по умолчанию) | old1000 | путь к manifest.json.
Подробнее о команде: uv run --frozen project <команда> --help
"""


# --- общие помощники -------------------------------------------------------------

def now_iso() -> str:
    return datetime.now(UTC).isoformat()


def new_run_id() -> str:
    # Тот же формат, что у запусков из веб-интерфейса.
    return datetime.now(UTC).strftime('run_%Y%m%d_%H%M%S_') + uuid.uuid4().hex[:6]


def display_path(path: Path) -> str:
    path = Path(path).resolve()
    try:
        return path.relative_to(ROOT).as_posix()
    except ValueError:
        return str(path)


def load_dataset(spec: str, verify: bool = False):
    """Ключ набора или путь к manifest.json -> ManifestData из model.load_manifest."""
    from model import load_manifest

    path = DATASETS.get(spec)
    if path is None:
        path = Path(spec)
        if not path.is_file():
            raise ValueError(
                f'Неизвестный набор {spec!r}: ожидается {" | ".join(DATASETS)} или путь к manifest.json.'
            )
    return load_manifest(path, verify_images=verify)


def kind_of(sample) -> str | None:
    return sample.params.get('kind')


def select(data, split: str, kind: str | None = None) -> list:
    items = data.by_split(split)
    if kind:
        items = [s for s in items if kind_of(s) == kind]
    if not items:
        where = f'split={split}' + (f', kind={kind}' if kind else '')
        raise ValueError(f'В наборе {data.dataset_name} нет примеров ({where}).')
    return items


def pick_one(data, args):
    if args.sample:
        for sample in data.samples:
            if sample.sample_id == args.sample:
                return sample
        raise ValueError(
            f'Пример {args.sample!r} не найден в наборе {data.dataset_name}. '
            'Список: project samples --dataset ... --split ...'
        )
    items = select(data, args.split, args.kind)
    if not 0 <= args.index < len(items):
        raise ValueError(f'--index {args.index} вне диапазона 0..{len(items) - 1} для split={args.split}.')
    return items[args.index]


def make_config(args) -> dict:
    device = args.device
    if device == 'auto':
        device = 'cuda' if torch.cuda.is_available() else 'cpu'
    if args.method == 'neural':
        if not args.weights:
            raise ValueError('--method neural требует --weights ПУТЬ_К_ЧЕКПОИНТУ (например model_zakha.pt).')
        weights = Path(args.weights).expanduser()
        if not weights.is_file():
            raise ValueError(f'Файл весов не найден: {weights}')
        if not 0 <= args.polish_steps <= 200:
            raise ValueError('--polish-steps: 0-200.')
        return {'method': 'neural', 'weights': str(weights.resolve()), 'polish_steps': args.polish_steps,
                'device': device, 'norm': 'max', 'compare': 'amplitude'}
    if args.weights:
        raise ValueError('--weights имеет смысл только вместе с --method neural.')
    # Те же поля и границы, что у веб-интерфейса и `python -m app --cli`.
    if not 1 <= args.iters <= 5000:
        raise ValueError('Итерации: 1-5000.')
    if not 0 <= args.seed <= 2147483647:
        raise ValueError('seed: 0-2147483647.')
    return {'iters': args.iters, 'seed': args.seed, 'device': device, 'norm': 'max', 'compare': 'amplitude'}


def describe(config: dict) -> str:
    if config.get('method') == 'neural':
        return (f'нейросеть HoloUnrollNet, веса {Path(config["weights"]).name}, '
                f'доработка фазы {config["polish_steps"]} шагов, устройство={config["device"]}')
    return f'baseline GS, {config["iters"]} итераций, seed={config["seed"]}, устройство={config["device"]}'


def fmt(value) -> str:
    return '-' if value is None else f'{value:.4f}'


def print_report(report: dict) -> None:
    header = f"{'Плоскость':<10}{'z, мм':>8}{'Pearson':>11}{'SSIM global':>13}{'SSIM skimage':>14}"
    print(header)
    print('-' * len(header))
    for row in report['planes']:
        print(
            f"{row['plane']:<10}{row['distance_mm']:>8.1f}{fmt(row['pearson']):>11}"
            f"{fmt(row['ssim_global']):>13}{fmt(row['ssim_skimage']):>14}"
        )
    print('-' * len(header))
    for label, key in (('среднее', 'mean'), ('минимум', 'minimum')):
        m = report[key]
        print(f"{label:<18}{fmt(m['pearson']):>11}{fmt(m['ssim_global']):>13}{fmt(m['ssim_skimage']):>14}")


def journal(folder: Path, echo: bool):
    """События адаптера -> events.jsonl и run.log в формате веб-интерфейса (+ строка в консоль)."""
    def emit(event: dict) -> None:
        entry = {'time': now_iso(), 'source': 'adapter', 'message': event['message']}
        with (folder / 'events.jsonl').open('a', encoding='utf-8') as f:
            f.write(json.dumps(entry, ensure_ascii=False) + '\n')
        with (folder / 'run.log').open('a', encoding='utf-8') as f:
            f.write(f'{entry["time"]} [adapter] {entry["message"]}\n')
        if echo:
            print(f'  [{event["stage"]}] {event["message"]}', flush=True)
    return emit


def calculate(folder: Path, data, sample, config: dict, echo: bool):
    """Один расчёт (baseline или нейросеть) для примера набора. Возвращает (report, parameters)."""
    sources = [data.root_dir / rel for rel in sample.images]
    for path in sources:
        validate_target(path)  # до создания папки: неудачные входы не оставляют мусорных запусков
    folder.mkdir(parents=True, exist_ok=False)
    for i, path in enumerate(sources, 1):
        shutil.copyfile(path, folder / f'input_{i:02}.png')
    meta = metadata(folder, config, list(sample.images))
    if config.get('method') == 'neural':
        meta['method'] = 'neural'
        meta['weights'] = neural.weights_info(config['weights'])
    meta['source'] = {
        'dataset': data.dataset_name,
        'dataset_version': data.dataset_version,
        'manifest': display_path(data.manifest_path),
        'sample_id': sample.sample_id,
        'split': sample.split,
        'kind': kind_of(sample),
    }
    write_json(folder / 'parameters.json', meta)
    try:
        report, timing = run_calculation(folder, config, journal(folder, echo))
        if config.get('method') == 'neural':
            meta['weights']['model'] = neural.model_info(config)
        meta.update(status='completed', timing=timing)
    except KeyboardInterrupt:
        meta.update(status='cancelled', error='Прервано пользователем (Ctrl+C).')
        raise
    except Exception as exc:
        meta.update(status='error', error=str(exc))
        raise
    finally:
        write_json(folder / 'parameters.json', meta)
    return report, meta


# --- команды ---------------------------------------------------------------------

def cmd_datasets(args) -> int:
    keys = [args.dataset] if args.dataset else list(DATASETS)
    status = 0
    for key in keys:
        try:
            data = load_dataset(key, verify=args.verify)
        except (ValueError, OSError) as exc:
            print(f'{key}: ОШИБКА - {exc}')
            status = 1
            continue
        print(f'{key}  {display_path(data.manifest_path)}')
        print(f'    {data.dataset_name}, версия {data.dataset_version}')
        parts = []
        for split, count in data.report.counts.items():
            kinds: dict[str, int] = {}
            for sample in data.by_split(split):
                if kind_of(sample):
                    kinds[kind_of(sample)] = kinds.get(kind_of(sample), 0) + 1
            detail = f' ({", ".join(f"{k} {n}" for k, n in sorted(kinds.items()))})' if len(kinds) > 1 else ''
            parts.append(f'{split} {count}{detail}')
        print('    ' + '; '.join(parts))
        if args.verify:
            print(f'    проверено PNG: {data.report.total_images} '
                  '(PNG, режим L, 128x128, сигнал/фон, не константа) - OK')
        for warning in data.report.warnings:
            print(f'    предупреждение: {warning}')
    if not args.verify and status == 0:
        print('\nБыстрая проверка манифестов. Прочитать и проверить все PNG: project datasets --verify')
    return status


def cmd_samples(args) -> int:
    if args.limit < 0:
        raise ValueError('--limit: 0 (все) или больше.')
    data = load_dataset(args.dataset)
    items = select(data, args.split, args.kind)
    shown = items if args.limit == 0 else items[:args.limit]
    print(f'{data.dataset_name}: split={args.split}' + (f', kind={args.kind}' if args.kind else '')
          + f' - {len(items)} примеров, показано {len(shown)}')
    for i, sample in enumerate(shown):
        print(f'{i:>5}  {sample.sample_id:<28}{kind_of(sample) or ""}')
    return 0


def cmd_run(args) -> int:
    data = load_dataset(args.dataset)
    sample = pick_one(data, args)
    config = make_config(args)
    if args.out:
        folder = Path(args.out)
        if folder.exists():
            raise ValueError(f'Папка {folder} уже существует. Укажите новую (запуски не перезаписываются).')
    else:
        jobs.RUNS.mkdir(exist_ok=True)
        folder = jobs.RUNS / new_run_id()
    print(f'Набор: {data.dataset_name} ({data.dataset_version})')
    print(f'Пример: {sample.sample_id}, split={sample.split}, kind={kind_of(sample) or "-"}')
    print(f'Расчёт: {describe(config)}')
    report, _ = calculate(folder, data, sample, config, echo=True)
    print()
    print_report(report)
    print(f'\nФайлы запуска: {display_path(folder)}')
    if not args.out:
        print('В веб-интерфейсе: project serve --open -> «История запусков» '
              '(сервер читает demo-runs/ при старте; если он уже запущен, перезапустите его).')
    return 0


def mean_of(rows: list[dict], key: str):
    values = [r[key] for r in rows if r[key] is not None]
    return float(np.mean(values)) if values else None


def csv_row(sample, report: dict) -> dict:
    # Колонки как у `doe_eval.cli evaluate`, плюс kind (группы Soft600 нужно смотреть отдельно).
    row = {'id': sample.sample_id, 'kind': kind_of(sample) or ''}
    row.update({f'{k}_mean': report['mean'][k] for k in METRICS})
    for plane in report['planes']:
        for k in METRICS:
            row[f'{k}_{plane["plane"]}'] = plane[k]
    return row


def cmd_batch(args) -> int:
    if args.start < 0 or (not args.all and args.limit < 1):
        raise ValueError('--start: 0 или больше, --limit: 1 или больше.')
    data = load_dataset(args.dataset)
    items = select(data, args.split, args.kind)[args.start:]
    if not args.all:
        items = items[:args.limit]
    if not items:
        raise ValueError(f'--start {args.start} за пределами выборки.')
    config = make_config(args)
    label = args.dataset if args.dataset in DATASETS else data.dataset_name
    stamp = datetime.now(UTC).strftime('%Y%m%d_%H%M%S')
    out = Path(args.out) if args.out else ROOT / 'runs' / f'{config.get("method", "baseline")}_{label}_{args.split}_{stamp}'
    if out.exists():
        raise ValueError(f'Папка {out} уже существует. Укажите новую (запуски не перезаписываются).')
    (out / 'doe').mkdir(parents=True)

    print(f'Набор: {data.dataset_name} ({data.dataset_version}), split={args.split}'
          + (f', kind={args.kind}' if args.kind else '') + f' - {len(items)} примеров')
    print(f'Расчёт: {describe(config)}')
    rows, failed = [], []
    for n, sample in enumerate(items, 1):
        print(f'[{n}/{len(items)}] {sample.sample_id} ... ', end='', flush=True)
        try:
            report, meta = calculate(out / sample.sample_id, data, sample, config, echo=False)
        except Exception as exc:  # noqa: BLE001 - один плохой пример не должен скрывать остальные
            failed.append({'id': sample.sample_id, 'error': f'{type(exc).__name__}: {exc}'})
            print(f'ОШИБКА: {exc}')
            continue
        shutil.copyfile(out / sample.sample_id / 'doe.png', out / 'doe' / f'{sample.sample_id}.png')
        rows.append(csv_row(sample, report))
        print(f'Pearson {fmt(report["mean"]["pearson"])}, SSIM global {fmt(report["mean"]["ssim_global"])}'
              f' ({meta["timing"]["total_s"]:.1f} с)')

    mean = {k: mean_of(rows, f'{k}_mean') for k in METRICS} if rows else None
    by_kind = {}
    for kind in sorted({r['kind'] for r in rows if r['kind']}):
        group = [r for r in rows if r['kind'] == kind]
        by_kind[kind] = {'count': len(group), **{k: mean_of(group, f'{k}_mean') for k in METRICS}}
    if rows:
        with (out / 'summary.csv').open('w', newline='', encoding='utf-8') as f:
            writer = csv.DictWriter(f, fieldnames=list(rows[0]))
            writer.writeheader()
            writer.writerows(rows)
    batch_report = {
        'created_at': now_iso(),
        'dataset': {'key': args.dataset, 'name': data.dataset_name, 'version': data.dataset_version,
                    'manifest': display_path(data.manifest_path)},
        'selection': {'split': args.split, 'kind': args.kind, 'start': args.start, 'count': len(items)},
        'config': config,
        'version': git_version(),
        'samples': rows,
        'failed': failed,
        'mean': mean,
        'mean_by_kind': by_kind,
    }
    if config.get('method') == 'neural':
        batch_report['weights'] = neural.weights_info(config['weights'])
    write_json(out / 'batch.json', batch_report)

    print(f'\nИтого: {len(rows)} из {len(items)} успешно.')
    if mean:
        print(f'  среднее        Pearson {fmt(mean["pearson"])}, SSIM global {fmt(mean["ssim_global"])}, '
              f'SSIM skimage {fmt(mean["ssim_skimage"])}')
    if len(by_kind) > 1:
        for kind, m in by_kind.items():
            print(f'  {kind} (n={m["count"]})  Pearson {fmt(m["pearson"])}, SSIM global {fmt(m["ssim_global"])}, '
                  f'SSIM skimage {fmt(m["ssim_skimage"])}')
    for item in failed:
        print(f'  не выполнено: {item["id"]} - {item["error"]}')
    print(f'Файлы: {display_path(out)} (summary.csv, batch.json, doe/<id>.png, папка на каждый пример)')
    return 1 if failed else 0


def cmd_serve(args) -> int:
    from .server import serve

    serve(port=args.port, open_browser=args.open)
    return 0


# --- разбор аргументов -----------------------------------------------------------

def build_parser(prog: str = 'project') -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog=prog,
        description='WhiteCollars: терминал для готовых наборов и baseline-синтеза ДОЭ.',
        epilog=EXAMPLES,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    sub = parser.add_subparsers(dest='command', metavar='команда')

    def command(name: str, help_: str, func):
        sp = sub.add_parser(name, help=help_, description=help_)
        sp.set_defaults(func=func)
        return sp

    def dataset_args(sp, default=DEFAULT_DATASET, split='validation'):
        sp.add_argument('--dataset', default=default, help='soft600 | old1000 | путь к manifest.json')
        sp.add_argument('--split', default=split, choices=['train', 'validation', 'test', 'diagnostic'])
        sp.add_argument('--kind', help='группа Soft600: soft_independent | physical_forward')

    def calc_args(sp):
        sp.add_argument('--method', choices=['baseline', 'neural'], default='baseline',
                        help='baseline = Герчберг-Сэкстон (по умолчанию); neural = HoloUnrollNet из --weights')
        sp.add_argument('--iters', type=int, default=200, help='baseline: итерации GS, 1-5000 (по умолчанию 200)')
        sp.add_argument('--seed', type=int, default=42, help='baseline: seed GS')
        sp.add_argument('--weights', help='neural: чекпоинт HoloUnrollNet, например model_zakha.pt')
        sp.add_argument('--polish-steps', type=int, default=25,
                        help='neural: шагов доработки фазы после сети, 0-200 (по умолчанию 25)')
        sp.add_argument('--device', choices=['cpu', 'cuda', 'auto'], default='cpu')
        sp.add_argument('--out', help='новая папка результата')

    sp = command('datasets', 'Показать готовые наборы; --verify читает и проверяет все PNG', cmd_datasets)
    sp.add_argument('--dataset', help='только этот набор (по умолчанию - все известные)')
    sp.add_argument('--verify', action='store_true', help='полная проверка всех PNG')

    sp = command('samples', 'Список примеров набора', cmd_samples)
    dataset_args(sp)
    sp.add_argument('--limit', type=int, default=20, help='сколько показать, 0 - все')

    sp = command('run', 'Один расчёт: baseline GS или нейросеть (по умолчанию baseline на диагностической четвёрке)', cmd_run)
    dataset_args(sp, split='diagnostic')
    sp.add_argument('--sample', help='sample_id, например soft1_train_000002 (вместо --split/--index)')
    sp.add_argument('--index', type=int, default=0, help='номер примера внутри split (с 0)')
    calc_args(sp)
    sp.epilog = ('Без --out результат кладётся в demo-runs/ и виден в «Истории запусков» веб-интерфейса '
                 'после его (пере)запуска.')

    sp = command('batch', 'Расчёт (baseline GS или нейросеть) на нескольких примерах split + сводка', cmd_batch)
    dataset_args(sp)
    sp.add_argument('--start', type=int, default=0, help='с какого примера начать (по умолчанию 0)')
    size = sp.add_mutually_exclusive_group()
    size.add_argument('--limit', type=int, default=8, help='сколько примеров (по умолчанию 8)')
    size.add_argument('--all', action='store_true', help='весь выбранный split')
    calc_args(sp)
    sp.epilog = 'Без --out результат кладётся в новую папку runs/baseline_<набор>_<split>_<время>/.'

    sp = command('serve', 'Запустить веб-интерфейс (127.0.0.1)', cmd_serve)
    sp.add_argument('--port', type=int, default=8765)
    sp.add_argument('--open', action='store_true', help='открыть браузер')
    return parser


def main(argv: list[str] | None = None, prog: str = 'project') -> int:
    for stream in (sys.stdout, sys.stderr):  # консоли Windows со старой кодировкой не должны падать
        if hasattr(stream, 'reconfigure'):
            stream.reconfigure(errors='replace')
    parser = build_parser(prog)
    args = parser.parse_args(argv)
    if not getattr(args, 'func', None):
        parser.print_help()
        return 0
    try:
        return args.func(args)
    except (ValueError, OSError) as exc:
        print(f'Ошибка: {exc}', file=sys.stderr)
        return 2
    except KeyboardInterrupt:
        print('\nПрервано.', file=sys.stderr)
        return 130
