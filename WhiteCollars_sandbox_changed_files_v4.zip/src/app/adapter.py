"""Thin, shared UI/CLI adapter. Scientific functions belong to doe_eval."""
from __future__ import annotations

import hashlib
import json
import subprocess
import time
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import torch
from PIL import Image, ImageDraw

from doe_eval.baseline import gerchberg_saxton_multiplane
from doe_eval.cli import evaluate_pair_arrays, reconstruct_from_doe_file
from doe_eval.config import DISTANCES, PIXEL, WAVELENGTH
from doe_eval.io import load_four_targets, load_gray_u8_png, save_doe_png, save_recon_png

ROOT = Path(__file__).resolve().parents[2]


def git_version():
    def read(*args):
        try:
            return subprocess.check_output(['git', '-C', str(ROOT), *args], stderr=subprocess.DEVNULL, timeout=2).decode().strip()
        except (OSError, subprocess.SubprocessError):
            return None
    overlay = {}
    for p in sorted((ROOT/'src/app').rglob('*')):
        if p.is_file() and p.suffix in ('.py','.js','.css','.html'):
            overlay[str(p.relative_to(ROOT))] = hashlib.sha256(p.read_bytes()).hexdigest()
    overlay['demo.py'] = hashlib.sha256((ROOT/'demo.py').read_bytes()).hexdigest()
    return {'branch': read('branch', '--show-current'), 'commit': read('rev-parse', 'HEAD'), 'local_demo': True, 'local_source_sha256': overlay}


def validate_target(path):
    # The dataset connector adds a signal/background contract to the PNG contract.
    a = load_gray_u8_png(path)
    if int(a.min()) != 0 or int(a.max()) == 0 or float(a.std()) == 0:
        raise ValueError('Нужны чёрный фон (min=0) и ненулевой сигнал. Пустые и постоянные изображения не принимаются.')
    return a


def diagnostic_paths():
    base = ROOT / 'src/dataset/data'
    manifest = json.loads((base / 'manifest.json').read_text())
    sample = next(s for s in manifest['samples'] if s['split'] == 'diagnostic')
    return sample['sample_id'], [base / name for name in sample['images']]


def write_json(path, value):
    tmp = path.with_suffix('.tmp')
    tmp.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False), encoding='utf-8')
    tmp.replace(path)


def run_calculation(folder, config, emit=print):
    """Called identically by the background worker and python -m app --cli."""
    started = time.perf_counter()
    paths = [folder / f'input_{i:02}.png' for i in range(1, 5)]
    device = torch.device(config['device'])
    if device.type == 'cuda' and not torch.cuda.is_available():
        raise ValueError('CUDA недоступна. Выберите CPU.')
    def sync():
        if device.type == 'cuda':
            torch.cuda.synchronize(device)
    def event(stage, message):
        emit({'stage': stage, 'message': message})
    event('validating', 'Проверка снимка четырёх входов: PNG · L · 128×128 · сигнал/фон.')
    for p in paths:
        validate_target(p)
    targets = load_four_targets(paths)
    target_tensor = torch.from_numpy(targets).to(device)
    sync()
    neural = config.get('method', 'baseline') == 'neural'
    weights_s = None
    if neural:
        # Доработка фазы нейросети считает градиенты, поэтому вне torch.inference_mode().
        from .neural import synthesize_phase
        phase, weights_s, synthesis_s = synthesize_phase(target_tensor, config, event)
        sync()
    else:
        event('synthesizing', f'gerchberg_saxton_multiplane: {config["iters"]} итераций, seed={config["seed"]}, {device}.')
        tick = time.perf_counter()
        with torch.inference_mode():
            phase = gerchberg_saxton_multiplane(target_tensor, iters=config['iters'], seed=config['seed'])
            sync()
        synthesis_s = time.perf_counter() - tick
    event('reconstructing', 'Сохранение doe.png. Повторное чтение 8-битной маски → Френель, |U|, norm=max.')
    tick = time.perf_counter()
    with torch.inference_mode():
        save_doe_png(phase.detach().cpu().numpy(), folder / 'doe.png')
        recons = reconstruct_from_doe_file(folder / 'doe.png', device, 'max', 'amplitude')
        sync()
        for i, a in enumerate(recons, 1):
            save_recon_png(a, folder / f'recon_{i}.png')
        reconstruction_s = time.perf_counter() - tick
    event('evaluating', 'evaluate_pair_arrays: Pearson, глобальный SSIM и оконный SSIM (scikit-image).')
    tick = time.perf_counter()
    report = evaluate_pair_arrays(targets, recons)
    keys = ('pearson', 'ssim_global', 'ssim_skimage')
    report['minimum'] = {key: min(row[key] for row in report['planes']) for key in keys}
    report.update(norm='max', compare='amplitude')
    if neural:
        report.update(method='neural', polish_steps=config['polish_steps'])
    else:
        report['iters'] = config['iters']
    # Pearson is mathematically undefined for a constant operand. Input validation
    # prevents constant targets; explicitly report the remaining exceptional case.
    for i, row in enumerate(report['planes']):
        if float(np.std(recons[i])) == 0:
            row['pearson'] = None
            row['pearson_reason'] = 'Нулевая дисперсия восстановления; Pearson не определён.'
    if any(row['pearson'] is None for row in report['planes']):
        report['mean']['pearson'] = None
        report['minimum']['pearson'] = None
    report['metric_protocol'] = {'ssim_primary': 'ssim_global', 'data_range': 1.0, 'k1': 0.01, 'k2': 0.03, 'source': 'doe_eval.cli.evaluate_pair_arrays', 'recon_metrics': 'normalized float amplitudes from re-read quantized DOE; recon PNG rounded for display'}
    write_json(folder / 'metrics.json', report)
    # Comparison uses the exact saved source/reconstruction PNGs, without filters.
    panel = Image.new('RGB', (4 * 276, 306), '#070c1c')
    draw = ImageDraw.Draw(panel)
    for i in range(4):
        x = i * 276 + 8
        draw.text((x, 8), f'Plane {i+1} | {DISTANCES[i]*1000:.1f} mm', fill='white')
        for j, name in enumerate((f'input_{i+1:02}.png', f'recon_{i+1}.png')):
            with Image.open(folder / name) as im:
                panel.paste(im.convert('RGB'), (x + j * 136, 40))
        draw.text((x, 180), 'Target               Reconstruction', fill='white')
        row = report['planes'][i]
        draw.text((x, 210), f'Pearson: {row["pearson"]}', fill='white')
        draw.text((x, 235), f'SSIM global: {row["ssim_global"]:.8f}', fill='white')
    panel.save(folder / 'panel.png')
    event('saving', 'metrics.json и panel.png записаны. Фиксация происхождения и измеренного времени.')
    timing = {'weights_s': weights_s, 'synthesis_s': synthesis_s, 'reconstruction_s': reconstruction_s, 'evaluation_save_s': time.perf_counter()-tick, 'total_s': time.perf_counter()-started}
    return report, timing


def metadata(folder, config, names):
    return {'id': folder.name, 'created_at': datetime.now(timezone.utc).isoformat(), 'status': 'validating', 'method': 'baseline', 'config': config, 'physics': {'distances_mm': [z*1000 for z in DISTANCES], 'wavelength_m': WAVELENGTH, 'pixel_m': PIXEL, 'field': '|U|', 'phase': '[-pi,+pi] → uint8 [0,255]', 'propagation': 'doe_eval.physics / single FFT Fresnel'}, 'inputs': [{'slot': i, 'name': names[i-1], 'sha256': hashlib.sha256((folder/f'input_{i:02}.png').read_bytes()).hexdigest()} for i in range(1,5)], 'weights': None, 'version': git_version(), 'adapter_protocol': 'whitecollars-local-demo/1', 'result_path': str(folder)}
