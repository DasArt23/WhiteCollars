"""Нейросетевой синтез фазы для общего адаптера: HoloUnrollNet (чекпоинт Захара).

Адаптер вызывает ``synthesize_phase`` вместо Герчберга-Сэкстона; дальше всё общее:
квантование в 8-битный ``doe.png``, повторное чтение, Френель, метрики. Поэтому
нейросеть и baseline оцениваются одной и той же физикой и одними и теми же метриками.
"""
from __future__ import annotations

import hashlib
import time
from functools import lru_cache
from pathlib import Path

import torch


@lru_cache(maxsize=4)
def _file_info(path: str, mtime_ns: int, size: int) -> dict:
    digest = hashlib.sha256()
    with open(path, 'rb') as f:
        for chunk in iter(lambda: f.read(1 << 20), b''):
            digest.update(chunk)
    return {'path': path, 'name': Path(path).name, 'size_bytes': size, 'sha256': digest.hexdigest()}


def weights_info(path) -> dict:
    """Происхождение весов: абсолютный путь, размер, sha256 (кэш по пути, mtime и размеру)."""
    p = Path(path).resolve()
    stat = p.stat()
    return dict(_file_info(str(p), stat.st_mtime_ns, stat.st_size))


def model_info(config) -> dict:
    """Архитектура загруженной модели для parameters.json."""
    from model.zakhar import get_model
    _, meta = get_model(config['weights'], config['device'])
    keys = ('epoch', 'unroll_steps', 'base_dim', 'equalize_plane_power', 'phase_carrier_seed', 'parameters')
    return {key: meta[key] for key in keys}


def synthesize_phase(targets, config, event):
    """Фаза [128, 128] по целям [4, 128, 128]; возвращает (фаза, секунды на веса, секунды на синтез)."""
    from model.zakhar import get_model, hybrid_infer_phase
    device = targets.device

    def sync():
        if device.type == 'cuda':
            torch.cuda.synchronize(device)

    tick = time.perf_counter()
    model, meta = get_model(config['weights'], device)
    weights_s = time.perf_counter() - tick
    steps = config['polish_steps']
    event('synthesizing', f'HoloUnrollNet ({Path(config["weights"]).name}): unroll_steps={meta["unroll_steps"]}, '
                          f'base_dim={meta["base_dim"]}, доработка фазы {steps} шагов, {device}.')
    sync()
    tick = time.perf_counter()
    phase = hybrid_infer_phase(model, targets.unsqueeze(0), polish_steps=steps)
    sync()
    synthesis_s = time.perf_counter() - tick
    phase = phase.squeeze(0).detach()
    if tuple(phase.shape) != (128, 128) or not bool(torch.isfinite(phase).all()):
        raise ValueError('Нейросеть вернула некорректную фазу: форма не 128×128 или есть NaN/Inf.')
    return phase, weights_s, synthesis_s
