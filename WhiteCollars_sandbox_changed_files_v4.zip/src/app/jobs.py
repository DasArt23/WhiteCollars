from __future__ import annotations

import base64
import json
import shutil
import subprocess
import sys
import threading
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path

from .adapter import ROOT, diagnostic_paths, metadata, validate_target, write_json

RUNS = ROOT / 'demo-runs'
UPLOADS = ROOT / '.demo-uploads'
TERMINAL = {'completed', 'error', 'cancelled'}


class JobManager:
    def __init__(self):
        RUNS.mkdir(exist_ok=True)
        UPLOADS.mkdir(exist_ok=True)
        self.lock = threading.RLock()
        self.jobs = {}
        self.active = None
        for folder in sorted(RUNS.iterdir()):
            if not folder.is_dir():
                continue
            try:
                meta = json.loads((folder/'parameters.json').read_text())
                if meta['status'] not in TERMINAL:
                    meta.update(status='cancelled', error='Сервер был перезапущен; расчёт прерван.')
                    write_json(folder/'parameters.json', meta)
                logs = [json.loads(line) for line in (folder/'events.jsonl').read_text().splitlines()] if (folder/'events.jsonl').exists() else []
                self.jobs[folder.name] = {'metadata': meta, 'logs': logs, 'process': None, 'start': None, 'cancel': False}
            except (OSError, ValueError, KeyError):
                continue

    def log(self, run_id, message, source='app', stage=None):
        with self.lock:
            job = self.jobs[run_id]
            entry = {'time': datetime.now(timezone.utc).isoformat(), 'source': source, 'message': message}
            job['logs'].append(entry)
            folder = RUNS/run_id
            with (folder/'events.jsonl').open('a', encoding='utf-8') as f:
                f.write(json.dumps(entry, ensure_ascii=False)+'\n')
            with (folder/'run.log').open('a', encoding='utf-8') as f:
                f.write(f'{entry["time"]} [{source}] {message}\n')
            if stage and stage not in TERMINAL and not job['cancel']:
                job['metadata']['status'] = stage

    def upload(self, payload):
        name = str(payload.get('name', 'input.png')).replace('\\', '/').split('/')[-1][:160]
        try:
            raw = base64.b64decode(payload['data'], validate=True)
        except (ValueError, KeyError):
            raise ValueError('Не удалось прочитать файл. Выберите PNG заново.')
        if not raw or len(raw) > 1024*1024:
            raise ValueError('Файл должен быть PNG 128×128 и не превышать 1 МБ.')
        token = uuid.uuid4().hex
        path = UPLOADS/f'{token}.png'
        path.write_bytes(raw)
        try:
            validate_target(path)
        except Exception:
            path.unlink(missing_ok=True)
            raise
        return {'token': token, 'name': name, 'preview': f'/api/uploads/{token}', 'valid': True}

    def example(self):
        sample_id, paths = diagnostic_paths()
        files = [self.upload({'name': p.name, 'data': base64.b64encode(p.read_bytes()).decode()}) for p in paths]
        return {'sample_id': sample_id, 'files': files}

    def start(self, data):
        with self.lock:
            if self.active:
                raise RuntimeError('Один расчёт уже выполняется. Дождитесь завершения или отмените его.')
            files = data.get('files')
            if not isinstance(files, list) or len(files) != 4:
                raise ValueError('Нужны ровно четыре PNG, по одному для каждой плоскости.')
            if data.get('method') != 'baseline':
                raise ValueError('Neural недоступен: в sandbox отсутствуют архитектура и обученные веса.')
            iters, seed = data.get('iters', 200), data.get('seed', 42)
            if type(iters) is not int or type(seed) is not int:
                raise ValueError('Итерации и seed должны быть целыми числами.')
            if not 1 <= iters <= 5000 or not 0 <= seed <= 2147483647:
                raise ValueError('Итерации: 1–5000. Seed: 0–2147483647.')
            device = data.get('device', 'cpu')
            if device not in ('cpu', 'cuda'):
                raise ValueError('Выберите CPU или доступную CUDA.')
            paths = []
            for f in files:
                if not isinstance(f, dict):
                    raise ValueError('Каждый слот должен содержать идентификатор загруженного PNG.')
                token = f.get('token', '')
                if not isinstance(token, str) or len(token) != 32 or any(c not in '0123456789abcdef' for c in token):
                    raise ValueError('Некорректный идентификатор входа. Загрузите файл заново.')
                p = UPLOADS/f'{token}.png'
                validate_target(p)
                paths.append(p)
            run_id = datetime.now(timezone.utc).strftime('run_%Y%m%d_%H%M%S_')+uuid.uuid4().hex[:6]
            folder = RUNS/run_id
            folder.mkdir()
            for i, p in enumerate(paths, 1):
                shutil.copyfile(p, folder/f'input_{i:02}.png')
            config = {'iters': iters, 'seed': seed, 'device': device, 'norm': 'max', 'compare': 'amplitude'}
            meta = metadata(folder, config, [str(f.get('name','input.png'))[:160] for f in files])
            write_json(folder/'parameters.json', meta)
            self.jobs[run_id] = {'metadata': meta, 'logs': [], 'process': None, 'start': time.monotonic(), 'cancel': False}
            self.active = run_id
            self.log(run_id, 'Снимок входов и настроек сохранён. Запускается отдельный Python-процесс.')
            threading.Thread(target=self._work, args=(run_id,), daemon=True).start()
            return self.snapshot(run_id)

    def _work(self, run_id):
        job = self.jobs[run_id]
        folder = RUNS/run_id
        try:
            process = subprocess.Popen([sys.executable, '-u', '-m', 'app.worker', str(folder)], cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, encoding='utf-8')
            with self.lock:
                job['process'] = process
                if job['cancel']:
                    process.terminate()
            def stderr():
                for line in process.stderr:
                    self.log(run_id, line.rstrip(), source='stderr')
            err_thread = threading.Thread(target=stderr, daemon=True)
            err_thread.start()
            for line in process.stdout:
                try:
                    event = json.loads(line)
                    self.log(run_id, event['message'], 'adapter', event.get('stage'))
                except (ValueError, KeyError):
                    self.log(run_id, line.rstrip(), 'stdout')
            code = process.wait()
            err_thread.join(timeout=3)
            with self.lock:
                saved = json.loads((folder/'parameters.json').read_text())
                if job['cancel']:
                    saved.update(status='cancelled')
                    self.log(run_id, 'Отмена подтверждена: процесс завершён. Частичные файлы не являются результатом.')
                elif code != 0:
                    saved.update(status='error', error=saved.get('error',f'Процесс завершился с кодом {code}. См. stderr.'))
                job['metadata'] = saved
        except Exception as exc:
            job['metadata'].update(status='error', error=str(exc))
            self.log(run_id, str(exc), 'stderr')
        finally:
            with self.lock:
                job['metadata']['wall_s'] = time.monotonic()-job['start']
                write_json(folder/'parameters.json', job['metadata'])
                job['process'] = None
                self.active = None

    def cancel(self, run_id):
        with self.lock:
            job = self.jobs[run_id]
            if job['metadata']['status'] in TERMINAL:
                return self.snapshot(run_id)
            job['cancel'] = True
            job['metadata']['status'] = 'cancelling'
            self.log(run_id, 'Отмена запрошена пользователем.')
            p = job['process']
            if p and p.poll() is None:
                p.terminate()
                def kill_if_needed():
                    try:
                        p.wait(timeout=3)
                    except subprocess.TimeoutExpired:
                        p.kill()
                threading.Thread(target=kill_if_needed, daemon=True).start()
            return self.snapshot(run_id)

    def snapshot(self, run_id):
        with self.lock:
            job = self.jobs[run_id]
            meta = dict(job['metadata'])
            report = None
            if meta['status'] == 'completed':
                try:
                    required = ['doe.png']+[f'input_{i:02}.png' for i in range(1,5)]+[f'recon_{i}.png' for i in range(1,5)]
                    missing = [name for name in required if not (RUNS/run_id/name).is_file()]
                    if missing:
                        raise ValueError('Отсутствуют файлы результата: '+', '.join(missing))
                    report = json.loads((RUNS/run_id/'metrics.json').read_text())
                    if not isinstance(report, dict) or len(report.get('planes',[])) != 4 or not all(isinstance(report.get(key),dict) for key in ('mean','minimum')):
                        raise ValueError('metrics.json имеет несовместимую структуру.')
                except (OSError, ValueError) as exc:
                    report = None
                    meta.update(status='error', error=f'Результат недоступен: {exc}')
                    job['metadata'] = meta
                    write_json(RUNS/run_id/'parameters.json',meta)
            elapsed = time.monotonic()-job['start'] if job['start'] and meta['status'] not in TERMINAL else meta.get('wall_s', meta.get('timing',{}).get('total_s',0))
            return {'metadata': meta, 'logs': list(job['logs']), 'metrics': report, 'elapsed_s': elapsed, 'artifacts': sorted(p.name for p in (RUNS/run_id).iterdir() if p.is_file() and p.suffix != '.tmp')}

    def history(self):
        with self.lock:
            return [dict(job['metadata']) for job in reversed(list(self.jobs.values()))]
