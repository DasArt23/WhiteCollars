'use strict';
const $ = s => document.querySelector(s);
const $$ = s => [...document.querySelectorAll(s)];
const icon = name => `<svg aria-hidden="true"><use href="#i-${name}"/></svg>`;
const esc = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
// Запуски из терминала могут быть нейросетевыми (--method neural): у них нет iters/seed.
const runTitle = m => m.method === 'neural' ? `Нейросеть · ${esc((m.weights && m.weights.name) || 'веса')}` : `GS · ${m.config.iters} итераций`;
const runSub = m => m.method === 'neural' ? `доработка ${m.config.polish_steps} шагов / ${esc(m.config.device)}` : `seed ${m.config.seed} / ${esc(m.config.device)}`;
const runSummary = m => m.method === 'neural' ? `нейросеть, доработка ${m.config.polish_steps} шагов` : `${m.config.iters} итераций`;
const distances = ['24,1', '25,3', '26,5', '27,7'];
const terminalStates = ['completed', 'error', 'cancelled'];
const stateNames = {validating:'Проверка входов',synthesizing:'Синтез фазовой маски',reconstructing:'Восстановление по Френелю',evaluating:'Расчёт метрик',saving:'Сохранение результатов',completed:'Расчёт завершён',error:'Ошибка расчёта',cancelling:'Отмена запрошена',cancelled:'Расчёт отменён'};
let inputs = [null,null,null,null], inputErrors = ['','','',''], uploading = new Set();
let current = null, activeId = null, savedView = false, logOffset = 0, logRendered = 0, pollTimer = null, busy = false, serverOnline = false, localLogs = [];

function showError(error) {
  $('#error-banner span').textContent = error instanceof Error ? error.message : String(error);
  $('#error-banner').hidden = false;
}
function toast(message) {
  $('#toast').textContent = message; $('#toast').hidden = false;
  clearTimeout(toast.timer); toast.timer = setTimeout(() => $('#toast').hidden = true, 3200);
}
async function api(path, data) {
  let response;
  try { response = await fetch(path, data === undefined ? {} : {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify(data)}); }
  catch (_) { throw new Error('Нет связи с локальным Python-сервером. Проверьте, что он запущен; сохранённые файлы остаются на диске.'); }
  const result = await response.json();
  if (!response.ok) throw new Error(result.error || `Ошибка HTTP ${response.status}`);
  return result;
}
function fileUrl(name) {return `/api/jobs/${encodeURIComponent(current.metadata.id)}/files/${encodeURIComponent(name)}`;}
function metric(value) {return typeof value === 'number' && Number.isFinite(value) ? value.toFixed(4) : '—';}
function seconds(value) {return typeof value === 'number' ? `${value.toFixed(2)} с` : '—';}
function modal(title, html) {$('#modal-title').textContent=title;$('#modal-content').innerHTML=html;$('#modal').showModal();}
function goView(view) {
  $('#workspace').hidden = view !== 'workspace'; $('#history').hidden = view !== 'history';
  $$('.nav-tab').forEach(b=>b.classList.toggle('active',b.dataset.view===view));
  if (view==='history') refreshHistory();
}
$$('.nav-tab').forEach(b=>b.addEventListener('click',()=>goView(b.dataset.view)));
$('#dismiss-error').onclick=()=>$('#error-banner').hidden=true;
$('#close-modal').onclick=()=>$('#modal').close();
$('#modal').addEventListener('click',e=>{if(e.target===$('#modal')){const r=$('#modal').getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)$('#modal').close();}});

function renderInputs() {
  $('#input-count').textContent=`${inputs.filter(Boolean).length} / 4`;
  $('#upload-grid').innerHTML=inputs.map((f,i)=>`<div class="upload-card ${f?'filled':''}" data-slot="${i}"><div class="upload-head"><b>${String(i+1).padStart(2,'0')}</b><span>${distances[i]} мм</span></div><button class="upload-target" data-choose="${i}" aria-label="${f?'Заменить':'Загрузить'} цель ${i+1}, ${distances[i]} мм">${f?`<img src="${esc(f.preview)}" alt="Цель плоскости ${i+1}">`:`${icon('upload')}<span>${uploading.has(i)?'Проверка…':'Выбрать PNG'}</span>`}</button><input type="file" accept="image/png,.png" data-file="${i}" hidden><div class="upload-bottom">${f?`<span class="valid-mark">✓</span><span class="filename" title="${esc(f.name)}">${esc(f.name)}</span><button class="upload-remove" data-remove="${i}" aria-label="Удалить цель ${i+1}">${icon('close')}</button>`:'<span>или перетащите сюда</span>'}</div>${inputErrors[i]?`<p class="upload-error">${esc(inputErrors[i])}</p>`:''}</div>`).join('');
  $$('[data-choose]').forEach(b=>b.onclick=()=>{$(`[data-file="${b.dataset.choose}"]`).click();});
  $$('[data-file]').forEach(f=>f.onchange=()=>{if(f.files[0])upload(Number(f.dataset.file),f.files[0]);});
  $$('[data-remove]').forEach(b=>b.onclick=()=>{inputs[Number(b.dataset.remove)]=null;inputErrors[Number(b.dataset.remove)]='';$('#example-note').textContent='Порядок слотов задаёт соответствие плоскостям.';renderInputs();renderResults();});
  $$('.upload-card').forEach(card=>{
    card.addEventListener('dragover',e=>{e.preventDefault();card.classList.add('dragging');});
    card.addEventListener('dragleave',()=>card.classList.remove('dragging'));
    card.addEventListener('drop',e=>{e.preventDefault();card.classList.remove('dragging');if(e.dataTransfer.files.length!==1){showError('Перетащите один PNG в конкретный слот. Так сохраняется порядок плоскостей.');return;}upload(Number(card.dataset.slot),e.dataTransfer.files[0]);});
  });
  updateControls();
}
async function upload(slot,file) {
  if(uploading.has(slot))return;
  uploading.add(slot);inputErrors[slot]='';renderInputs();
  try {
    if(file.size>1024*1024)throw new Error('PNG не должен превышать 1 МБ.');
    const data=await new Promise((resolve,reject)=>{const r=new FileReader();r.onload=()=>resolve(r.result.split(',')[1]);r.onerror=()=>reject(new Error('Не удалось прочитать файл.'));r.readAsDataURL(file);});
    const f=await api('/api/uploads',{name:file.name,data});inputs[slot]=f;
    $('#example-note').textContent='Порядок слотов задаёт соответствие плоскостям.';
  } catch(error) {inputErrors[slot]=error.message;showError(`Цель ${slot+1}: ${error.message}`);}
  finally {uploading.delete(slot);renderInputs();renderResults();}
}
$('#load-example').onclick=async()=>{
  $('#load-example').disabled=true;
  try {const r=await api('/api/example',{});inputs=r.files;inputErrors=['','','',''];$('#example-note').textContent=`Диагностика ${r.sample_id} · не train и не test.`;renderInputs();renderResults();toast('Четыре диагностические цели загружены.');}
  catch(e){showError(e);}finally{$('#load-example').disabled=false;}
};
function updateControls() {
  const valid=inputs.every(Boolean)&&!uploading.size;
  $('#run-button').disabled=busy||!!activeId||!valid||!serverOnline;
  if(!current&&!activeId){$('#process-title').textContent=valid?'Готов к синтезу':'Ожидание входов';$('#process-description').textContent=valid?'Четыре цели проверены. Можно запускать baseline.':'Добавьте четыре цели для начала расчёта.';$('#process-chip').textContent=valid?'ГОТОВ':'ОЖИДАНИЕ';}
  $('#cancel-button').hidden=!activeId;
  $('#cancel-button').disabled=busy||current?.metadata.status==='cancelling';
  $('#run-mode').textContent=`BASELINE · ${$('#device').value.toUpperCase()}`;
}
$('#device').onchange=updateControls;

$('#run-button').onclick=async()=>{
  if($('#run-button').disabled)return;
  const iters=Number($('#iterations').value),seed=Number($('#seed').value);
  if(!Number.isInteger(iters)||iters<1||iters>5000){showError('Число итераций должно быть целым: от 1 до 5000.');$('#iterations').focus();return;}
  if(!Number.isInteger(seed)||seed<0||seed>2147483647){showError('Seed должен быть целым: от 0 до 2147483647.');$('#seed').focus();return;}
  busy=true;updateControls();
  try {
    current=await api('/api/jobs',{method:'baseline',files:inputs.map(f=>({token:f.token,name:f.name})),iters,seed,device:$('#device').value});
    activeId=current.metadata.id;savedView=false;logOffset=0;logRendered=0;$('#log').innerHTML='';
    localStorage.setItem('wc-last-run',current.metadata.id);$('#error-banner').hidden=true;renderJob();schedulePoll();refreshHistory();
  }catch(e){showError(e);}finally{busy=false;updateControls();}
};
$('#cancel-button').onclick=async()=>{
  if(!activeId)return;busy=true;updateControls();
  try{current=await api(`/api/jobs/${activeId}/cancel`,{});renderJob();}catch(e){showError(e);}finally{busy=false;updateControls();}
};
function schedulePoll(){clearTimeout(pollTimer);if(activeId)pollTimer=setTimeout(pollJob,650);}
async function pollJob(){
  if(!activeId)return;
  try{
    const r=await api(`/api/jobs/${activeId}`);current=r;renderJob();
    if(terminalStates.includes(r.metadata.status)){activeId=null;updateControls();refreshHistory();if(r.metadata.status==='completed')toast('Расчёт завершён. Результаты сохранены.');if(r.metadata.status==='error')showError(r.metadata.error||'Ошибка расчёта. Подробности в журнале.');}
  }catch(e){showError(e);$('#server-state').className='server-state offline';$('#server-state').innerHTML='<i></i>Связь потеряна';}
  schedulePoll();
}
function renderJob(){
  if(!current)return;
  const m=current.metadata,s=m.status;
  $('#process-title').textContent=stateNames[s]||s;
  const descriptions={completed:'Четыре восстановления оценены. Артефакты сохранены.',synthesizing:'Выполняется многоплоскостной GS. Процент не сообщается.',reconstructing:'Из сохранённой 8-битной маски, поле |U|.',evaluating:'Метрики рассчитываются в Python для каждой плоскости.',saving:'Фиксация файлов, параметров и происхождения.',validating:'Проверка снимка входных изображений.',cancelling:'Ожидание завершения Python-процесса.',cancelled:'Частичные файлы доступны в журнале и списке файлов.',error:m.error||'Подробности и traceback сохранены в журнале.'};
  $('#process-description').textContent=descriptions[s]||'';
  $('#process-chip').textContent=({completed:'ЗАВЕРШЁН',error:'ОШИБКА',cancelled:'ОТМЕНЁН',cancelling:'ОТМЕНА'})[s]||'ВЫПОЛНЯЕТСЯ';
  const kind=s==='completed'?'completed':s==='error'?'error':terminalStates.includes(s)?'':'running';
  $('#process-chip').className=`status-chip ${kind}`;$('#process-indicator').className=`waiting-dot ${kind}`;
  $('#elapsed').textContent=seconds(current.elapsed_s);
  const order=['validating','synthesizing','reconstructing','evaluating','saving','completed'];const index=order.indexOf(s);
  $$('#pipeline span').forEach(p=>{const j=order.indexOf(p.dataset.stage);p.classList.toggle('done',index>j);p.classList.toggle('active',index===j);});
  $('#show-files').disabled=!current.artifacts.length;
  $('#export-button').disabled=!terminalStates.includes(s);
  renderLogs();renderResults();updateControls();
}
function renderLogs(){
  const logs=current?current.logs:localLogs;
  const area=$('#log');const atBottom=area.scrollHeight-area.scrollTop-area.clientHeight<35;
  if(logRendered>logs.length||logRendered<logOffset){area.innerHTML='';logRendered=logOffset;}
  if(logRendered===0&&logs.length)area.innerHTML='';
  const fragment=document.createDocumentFragment();
  for(let i=Math.max(logRendered,logOffset);i<logs.length;i++){
    const e=logs[i],row=document.createElement('div');row.className=`log-line ${e.source==='stderr'?'stderr':''}`;
    const date=new Date(e.time);const t=date.toLocaleTimeString('ru-RU',{hour12:false});
    row.innerHTML=`<span class="log-time">${esc(t)}</span><span class="log-source">[${esc(e.source)}]</span><span>${esc(e.message)}</span>`;fragment.append(row);
  }
  area.append(fragment);logRendered=logs.length;
  $('#log-count').textContent=`${logs.length} событий`;
  if(atBottom)area.scrollTop=area.scrollHeight;
}
function renderResults(){
  const ready=current?.metadata.status==='completed'&&current.metrics;
  const m=current?.metadata,report=ready?current.metrics:null;
  $('#mean-pearson').textContent=metric(report?.mean.pearson);$('#mean-ssim').textContent=metric(report?.mean.ssim_global);
  $('#min-pearson').textContent=`min ${metric(report?.minimum.pearson)}`;$('#min-ssim').textContent=`min ${metric(report?.minimum.ssim_global)}`;
  $('#synthesis-time').textContent=seconds(ready?m.timing?.synthesis_s:undefined);
  $('#result-label').innerHTML=`<i></i>${current?(savedView?'СОХРАНЁННЫЙ ЗАПУСК':ready?'ФАКТИЧЕСКИЙ РЕЗУЛЬТАТ':terminalStates.includes(m.status)?'РАСЧЁТ НЕ ЗАВЕРШЁН':'РЕЗУЛЬТАТЫ ОЖИДАЮТСЯ'):'РАСЧЁТ НЕ ЗАПУЩЕН'}`;
  $('#result-id').textContent=m?.id||'—';$('.result-context').classList.toggle('ready',!!ready);
  $('#results-grid').innerHTML=distances.map((z,i)=>{
    const row=report?.planes[i];
    const target=current?fileUrl(`input_${String(i+1).padStart(2,'0')}.png`):inputs[i]?.preview;
    const recon=ready&&current.artifacts.includes(`recon_${i+1}.png`)?fileUrl(`recon_${i+1}.png`):null;
    const img=(src,type)=>src?`<button data-zoom="${esc(src)}" data-caption="${type} · плоскость ${i+1}, ${z} мм" aria-label="Увеличить: ${type}, плоскость ${i+1}"><img src="${esc(src)}" alt="${type} ${i+1}" loading="lazy"></button>`:icon(type==='Цель'?'upload':'expand');
    return `<article class="result-card"><div class="result-head"><b>ПЛОСКОСТЬ ${String(i+1).padStart(2,'0')}</b><span>${z} мм</span></div><div class="image-pair"><div class="image-box">${img(target,'Цель')}</div><div class="image-box">${img(recon,'Восстановление')}</div></div><div class="image-caption"><span>Цель</span><span>${recon?'Восстановление':'Ожидание'}</span></div><div class="plane-metrics"><span title="${esc(row?.pearson_reason||'Коэффициент Пирсона')}">r <b>${metric(row?.pearson)}</b></span><span>SSIM <b>${metric(row?.ssim_global)}</b></span></div></article>`;
  }).join('');
  $('#phase-image').disabled=!ready;$('#phase-image').innerHTML=ready?`<img src="${fileUrl('doe.png')}" alt="Фазовая маска, −π…+π">`:'<span>φ</span>';
  $('#result-path').textContent=m?`${m.id} / ${m.status==='completed'?'Все файлы сохранены':stateNames[m.status]||m.status}`:'Архив: входы, маска, восстановления, метрики и журнал.';
  $$('[data-zoom]').forEach(b=>b.onclick=()=>zoom(b.dataset.zoom,b.dataset.caption));
  $$('.image-box img').forEach(im=>im.onerror=()=>{const box=im.closest('.image-box');box.textContent='Файл недоступен';box.style.fontSize='9px';});
}
function zoom(src,caption){modal(caption,`<img class="zoom-image" src="${esc(src)}" alt="${esc(caption)}"><p>Просмотр исходного PNG. Масштабирование без фильтров и изменения файла.</p><a class="file-link" href="${esc(src)}" target="_blank" rel="noreferrer">Открыть PNG в исходном размере ${icon('expand')}</a>`);}
$('#phase-image').onclick=()=>{if(!$('#phase-image').disabled)zoom(fileUrl('doe.png'),'Фазовая маска ДОЭ · −π…+π');};
$('#export-button').onclick=()=>{if(current)download(`/api/jobs/${current.metadata.id}/archive`);};
function download(url){const a=document.createElement('a');a.href=url;a.download='';document.body.append(a);a.click();a.remove();}
$('#show-files').onclick=()=>{
  if(!current)return;
  modal('Файлы запуска',`<p><strong>${esc(current.metadata.id)}</strong></p><p>${esc(stateNames[current.metadata.status])} · ${esc(current.metadata.config.device)} · ${runSummary(current.metadata)}</p>${current.artifacts.map(f=>`<a class="file-link" href="${fileUrl(f)}" target="_blank" rel="noreferrer">${esc(f)}${icon('arrow')}</a>`).join('')}<p>Папка результата:<br><code>${esc(current.metadata.result_path)}</code></p>`);
};
function logText(){return(current?current.logs:localLogs).map(e=>`${e.time} [${e.source}] ${e.message}`).join('\n');}
$('#copy-log').onclick=async()=>{try{await navigator.clipboard.writeText(logText());toast('Журнал скопирован.');}catch(e){showError('Буфер обмена недоступен. Используйте кнопку «Сохранить журнал».');}};
$('#save-log').onclick=()=>{const b=new Blob([logText()],{type:'text/plain;charset=utf-8'}),url=URL.createObjectURL(b);const a=document.createElement('a');a.href=url;a.download=current?`${current.metadata.id}.log`:'whitecollars.log';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);};
$('#clear-log').onclick=()=>{logOffset=current?current.logs.length:localLogs.length;logRendered=logOffset;$('#log').innerHTML='';toast('Отображение очищено. Полный журнал сохранён.');};

async function refreshHistory(){
  try{
    const history=await api('/api/history');$('#history-count').textContent=history.length;
    $('#history-list').innerHTML=history.length?history.map(m=>`<div class="history-row"><div><b>${esc(m.id)}</b><small>${new Date(m.created_at).toLocaleString('ru-RU')}</small></div><div><b>${runTitle(m)}</b><small>${runSub(m)}</small></div><div><b>${esc(stateNames[m.status]||m.status)}</b><small>${m.timing?`Синтез ${seconds(m.timing.synthesis_s)}`:'Результат не готов'}</small></div><button class="secondary" data-open-run="${esc(m.id)}">Открыть ${icon('arrow')}</button></div>`).join(''):'<div class="history-empty">Запусков пока нет.<br>Загрузите диагностическую четвёрку и запустите baseline.</div>';
    $$('[data-open-run]').forEach(b=>b.onclick=()=>openRun(b.dataset.openRun));
  }catch(e){showError(e);}
}
$('#refresh-history').onclick=refreshHistory;
async function openRun(id){
  if(activeId&&activeId!==id){showError('Сейчас выполняется расчёт. Дождитесь его завершения или отмените, чтобы открыть сохранённый запуск.');return;}
  try{current=await api(`/api/jobs/${id}`);savedView=true;logOffset=0;logRendered=0;$('#log').innerHTML='';localStorage.setItem('wc-last-run',id);goView('workspace');renderJob();if(!terminalStates.includes(current.metadata.status)){activeId=id;schedulePoll();}}
  catch(e){showError(e);}
}
function protocol(){modal('Физика и протокол оценки',`<p>Вычисления выполняет существующий модуль <strong>doe_eval</strong>. Физические параметры в демо фиксированы.</p><dl><dt>Длина волны</dt><dd>532 нм</dd><dt>Пиксель ДОЭ</dt><dd>10 мкм</dd><dt>Размер маски</dt><dd>128 × 128</dd><dt>Расстояния от ДОЭ</dt><dd>24,1 / 25,3 / 26,5 / 27,7 мм</dd><dt>Распространение</dt><dd>Френель / 1 FFT</dd><dt>Сравниваемое поле</dt><dd>Модуль |U|</dd><dt>Нормировка</dt><dd>max / по каждой плоскости</dd><dt>Основной SSIM</dt><dd>Глобальный, K₁=.01, K₂=.03</dd><dt>Дополнительный SSIM</dt><dd>Оконный scikit-image / JSON</dd><dt>Кодирование маски</dt><dd>0 → −π, 255 → +π</dd></dl><p>Метрики считаются по нормированным float-амплитудам из сохранённой и перечитанной маски. Восстановления PNG округлены до 8 бит для отображения. Все значения с полной точностью доступны в <strong>metrics.json</strong>.</p>`);}
$('#physics-button').onclick=protocol;$('#ssim-info').onclick=protocol;
$('#about-button').onclick=()=>modal('Локальное демо / ORBIT 02',`<p><strong>WHITE COLLARS — «Белые воротнички»</strong><br>Исследовательская лаборатория фотоники, кафедра №37 НИЯУ МИФИ. Nuclear IT Hack.</p><p>Это отдельная версия для оценки интерфейса. Baseline Герчберга—Сэкстона выполняет настоящий расчёт. <strong>В sandbox нет архитектуры нейросети и обученных весов</strong>, поэтому neural недоступен.</p><p>Один запуск не является бенчмарком. Время синтеза измеряется отдельно от восстановления, загрузки страницы и отрисовки.</p><p>Оформление, логотип и Луна взяты из <strong>WhiteCollars_presentation.html</strong>. Шрифты хранятся локально. Демо не вносит изменений в удалённый репозиторий.</p>`);

function endIntro(){const el=$('#intro');if(el.hidden)return;el.classList.add('leaving');sessionStorage.setItem('wc-intro','seen');setTimeout(()=>el.hidden=true,450);}
$('#skip-intro').onclick=endIntro;
if(sessionStorage.getItem('wc-intro')||matchMedia('(prefers-reduced-motion: reduce)').matches)$('#intro').hidden=true;else setTimeout(endIntro,3900);
document.addEventListener('keydown',e=>{if((e.ctrlKey||e.metaKey)&&e.key==='Enter'&&!$('#modal').open){e.preventDefault();$('#run-button').click();}});

async function boot(){
  renderInputs();renderResults();
  try{
    const s=await api('/api/status');serverOnline=true;
    $('#server-state').className='server-state online';$('#server-state').innerHTML='<i></i>Сервер онлайн';
    $('#git-version').textContent=s.version.commit?`${s.version.branch} / ${s.version.commit.slice(0,7)} + local demo`:'Версия Git недоступна';
    if(s.cuda){$('#device option[value="cuda"]').disabled=false;$('#device option[value="cuda"]').textContent='CUDA — доступна';}
    localLogs=[{time:new Date().toISOString(),source:'ui',message:'Соединение с локальным Python-сервером установлено.'},{time:new Date().toISOString(),source:'ui',message:'Baseline доступен. Neural отключён: нет архитектуры и весов в sandbox.'}];
    renderLogs();updateControls();refreshHistory();
    if(s.active){activeId=s.active;await openRun(s.active);savedView=false;}
    else{const last=localStorage.getItem('wc-last-run');if(last){try{await openRun(last);}catch(_){localStorage.removeItem('wc-last-run');}}}
  }catch(e){$('#server-state').className='server-state offline';$('#server-state').innerHTML='<i></i>Сервер недоступен';showError(e);}
}
boot();
