from __future__ import annotations

import argparse
import shutil
import sys
from pathlib import Path

# Подкоманды терминального интерфейса (app/terminal.py); список сверяется тестом.
TERMINAL_COMMANDS = ('datasets', 'samples', 'run', 'batch', 'serve')


def main():
    if len(sys.argv) > 1 and sys.argv[1] in TERMINAL_COMMANDS:
        from .terminal import main as terminal_main
        raise SystemExit(terminal_main(sys.argv[1:], prog='python -m app'))
    parser = argparse.ArgumentParser(
        description='WhiteCollars local demo',
        epilog='Терминальные команды для готовых наборов: ' + ', '.join(TERMINAL_COMMANDS)
               + ' (python -m app <команда> --help).',
    )
    parser.add_argument('--port',type=int,default=8765)
    parser.add_argument('--open',action='store_true',help='Открыть браузер после готовности сервера')
    parser.add_argument('--cli',action='store_true')
    parser.add_argument('--inputs',nargs=4)
    parser.add_argument('--out')
    parser.add_argument('--iters',type=int,default=200)
    parser.add_argument('--seed',type=int,default=42)
    parser.add_argument('--device',choices=['cpu','cuda'],default='cpu')
    args = parser.parse_args()
    if args.cli:
        from .adapter import metadata, run_calculation, validate_target, write_json
        if not args.inputs or not args.out:
            parser.error('--cli требует --inputs и --out')
        if not 1 <= args.iters <= 5000 or not 0 <= args.seed <= 2147483647:
            parser.error('Итерации: 1–5000, seed: 0–2147483647')
        for source in args.inputs:
            validate_target(source)
        folder = Path(args.out).resolve()
        folder.mkdir(parents=True,exist_ok=False)
        for i, source in enumerate(args.inputs,1):
            shutil.copyfile(source,folder/f'input_{i:02}.png')
        config = {'iters':args.iters,'seed':args.seed,'device':args.device,'norm':'max','compare':'amplitude'}
        meta = metadata(folder,config,[Path(p).name for p in args.inputs])
        write_json(folder/'parameters.json',meta)
        try:
            _, timing = run_calculation(folder,config)
            meta.update(status='completed',timing=timing)
        except Exception as exc:
            meta.update(status='error',error=str(exc))
            raise
        finally:
            write_json(folder/'parameters.json',meta)
    else:
        from .server import serve
        serve(port=args.port,open_browser=args.open)


if __name__ == '__main__':
    main()
