"""Точка входа проекта: ``uv run --frozen project`` (см. [project.scripts] в pyproject.toml)."""


def main() -> int:
    from app.terminal import main as terminal_main

    return terminal_main()


if __name__ == "__main__":
    raise SystemExit(main())
